package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.adapter.NotificationAdapter;
import com.example.root.mecanomandroidhackaton.model.Notifications;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;



public class getAllNotif {
    private Users users = null;
    private Context context ;
    private String token;
    List<Notifications> notifications = new ArrayList<Notifications>();
    private NotificationAdapter adapter;
    private boolean haveNotif = false;

    public getAllNotif(Users users, Context context, NotificationAdapter adapter ) {
        this.users = users;
        this.context = context;
        this.adapter = adapter;
    }


    public boolean getAll( ) {


        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("un instant ...");
        progressDialog.show();

        ApiService service = getApiService();
        token = "Bearer " + users.getToken();
        Call<List<Notifications>> call = service.getAllNotif(token,users.getId() );
        Log.i("Halla", "" + users.getId()+""+users.getIsMechanic());


        call.enqueue(new Callback<List<Notifications>>() {
            @Override
            public void onResponse(Call<List<Notifications>> call, Response<List<Notifications>> response) {
                Log.i("Halla", "" + response);
                if (response.code() == 200) {
                    haveNotif = true;
                    notifications = response.body();
                    if (notifications.size() == 0) {

                        adapter.setItems(notifications);

                        Utils.ToastMsg(context,"pas de notification disponible");

                    }
                    else {
                        adapter.setItems(notifications);

                    }
//                    ((Activity)context).findViewById(R.id.loadingPanel).setVisibility(View.GONE);


                } else {
                    notifications = null;
                    Utils.ToastMsg(context,"erreur du cote du serveur,glisser pour recharger");

                }
                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<List<Notifications>> call, Throwable t) {
                Log.i("Hello", "" + t);
                notifications = null;
                progressDialog.dismiss();
                Utils.ToastMsg(context,"erreur du cote du serveur2,reesayez");
//                ((Activity)context).findViewById(R.id.loadingPanel).setVisibility(View.GONE);
            }
        });

        return haveNotif;
    }
}
