package com.example.root.mecanomandroidhackaton.adapter;

import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.root.mecanomandroidhackaton.ControlModel.getNotifInfo;
import com.example.root.mecanomandroidhackaton.model.Notifications;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.example.root.mecanomandroidhackaton.R;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;



public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private List<Notifications> items= new ArrayList<Notifications>();
    private Notifications item;
    private int ismechanic;
    private Context context;
    private Users users;
    private float ratingbar_value;

    public NotificationAdapter(List<Notifications> items, int ismechanic, Context context, Users users) {
        this.items = items;
        this.ismechanic = ismechanic;
        this.context = context;
        this.users = users;
    }

    public void setItems(List<Notifications> items) {
        this.items = items;
        Collections.reverse(this.items);
        this.notifyDataSetChanged();
    }

    @Override
    public NotificationAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lay_notif, parent, false);
        return new NotificationAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final NotificationAdapter.ViewHolder holder, int position) {
        item = items.get(position);

//        holder.titleText.setText(item.getTitle());
        holder.messageText.setText(item.getBody());
        holder.date.setText(item.getDate());

        holder.Btn_Del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                remove from list
                items.remove(item);

                notifyItemRemoved(holder.getAdapterPosition());
                notifyItemRangeChanged(holder.getAdapterPosition(),items.size());
            }
        });

        if(ismechanic ==1){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (Utils.isIntenetAvailavle(context))
                        new getNotifInfo(users,context, items.get(holder.getAdapterPosition()).getId()).getIt();
                    else
                        Utils.ToastMsg(context,"verifiez votre connection,reessayez");

                }
            });


        }
        else{
            if(item.getStatus() ==0) {
//                holder.itemView.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//
//                        LayoutInflater inflater1 = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
//                        View layout = inflater1.inflate(R.layout.rate_services, null);
//                        RatingBar ratingBar = layout.findViewById(R.id.rate);
//                        TextView okAlert = layout.findViewById(R.id.ok);
//                        ImageButton imageButton = layout.findViewById(R.id.btn_close);
//                        if (layout.getParent() != null)
//                            ((ViewGroup) layout.getParent()).removeView(layout);
//
//
//                        final AlertDialog alertDialog = new AlertDialog.Builder(context).create();
//                        alertDialog.setView(layout);
//                        alertDialog.show();
//
//
//                        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
//                            @Override
//                            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
//                                ratingbar_value = v;
//                            }
//                        });
//                        okAlert.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View view) {
////                                if (Utils.isIntenetAvailavle(context))
////                                    new setRating(context,users,  item.getMechanic_id(),ratingbar_value).setIt();
////                                else
////                                    Utils.ToastMsg(context,"verifiez votre connection,reessayez");
//                            }
//                        });
//                        imageButton.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View view) {
//                                alertDialog.dismiss();
//                            }
//                        });
//
//
//                    }
//                });

            }
        }
    }



    @Override
    public int getItemCount() {
        return items.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView messageText, titleText,date;
        private ImageButton Btn_Del;
        public ViewHolder(View itemView) {
            super(itemView);
            messageText = (TextView)itemView.findViewById(R.id.msg);
            titleText = (TextView)itemView.findViewById(R.id.title);
            date = (TextView)itemView.findViewById(R.id.date);
            Btn_Del = (ImageButton)itemView.findViewById(R.id.delete);
        }
    }
}
