package com.example.root.mecanomandroidhackaton.DestinMLogin;

/**
 * Copyright (c) 2017 Codelight Studios
  */

public enum LoginType {
    Facebook,
    Google,
    CustomLogin,
    CustomSignup
}
