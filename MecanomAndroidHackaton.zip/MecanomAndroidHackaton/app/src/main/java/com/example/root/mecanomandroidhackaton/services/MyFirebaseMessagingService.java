package com.example.root.mecanomandroidhackaton.services;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.App;
import com.example.root.mecanomandroidhackaton.ControlModel.sendFbTokenToServer;
import com.example.root.mecanomandroidhackaton.R;
import com.example.root.mecanomandroidhackaton.util.UtilsMecanom;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import static android.app.NotificationManager.IMPORTANCE_HIGH;


public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "MyFirebaseMsgService";

    @Override
    public void onNewToken(String token) {
        // Get updated InstanceID token.
//        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
//        Log.d(TAG, "Refreshed token: " + refreshedToken);

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.
        if(token!=null){
            UtilsMecanom.saveFbToken(token, this);
            new sendFbTokenToServer(this).sendRegistrationToServer(token);
//            Toast.makeText(App.getAppContext(), token, Toast.LENGTH_SHORT).show();

        }

    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // ...

        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());

//            if (/* Check if data needs to be processed by long running job */ true) {
                // For long-running tasks (10 seconds or more) use Firebase Job Dispatcher.
                scheduleJob();
//            } else {
//                // Handle message within 10 seconds
//                handleNow();
//            }

        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }

        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated. See sendNotification method below.
    }

    private void scheduleJob(){
        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this,getString(R.string.CHANNEL_ID))
                .setSmallIcon(R.drawable.logo_min)
                .setContentTitle("Mekano'M")
                .setContentText("nouvelle notification")
                .setSound(defaultSoundUri)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);


        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

//        if(UtilsMecanom.isLoggedIn(this))
//        {
//            PendingIntent contentIntent = PendingIntent.getActivity(App.getAppContext(), 0,
//                    new Intent(this, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
//             notificationBuilder.setContentIntent(contentIntent);
//
//        }
//
//        else{
//            PendingIntent contentIntent = PendingIntent.getActivity(App.getAppContext(), 0,
//                    new Intent(this, LoginActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
//            notificationBuilder.setContentIntent(contentIntent);
//        }




        // Builds the notification and issues it.
        if (notificationManager != null) {
            Log.d(TAG, "Message Notificaccction  : "  );

            if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
            {
                String channelId = "1";
                NotificationChannel channel = new NotificationChannel(channelId,
                            "Channel human readable title", IMPORTANCE_HIGH);
                notificationManager.createNotificationChannel(channel);
                notificationBuilder.setChannelId(channelId);
            }


            notificationManager.notify(0, notificationBuilder.build());


        }

//        Intent intent = new Intent();
//        LocalBroadcastManager broadcaster =  LocalBroadcastManager.getInstance(this);
//        broadcaster.sendBroadcast(intent);


    }

    private void handleNow(){
        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this,getString(R.string.CHANNEL_ID))
                .setSmallIcon(R.drawable.logo_min)
                .setContentTitle("Mekano'M")
                .setContentText("nouvelle notification")
                .setSound(defaultSoundUri)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
    }
}
