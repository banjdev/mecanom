package com.example.root.mecanomandroidhackaton.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.root.mecanomandroidhackaton.ControlModel.getAllMaker;
import com.example.root.mecanomandroidhackaton.R;
import com.example.root.mecanomandroidhackaton.activity.MenuActivity;
import com.example.root.mecanomandroidhackaton.model.DetailVehicule;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.gson.Gson;

import static android.content.Context.MODE_PRIVATE;
import static com.example.root.mecanomandroidhackaton.util.Utils.YearSpinner;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_DetailVehicule;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.TransmissionValue;


public class VehicleFragment extends android.support.v4.app.Fragment {

    private Spinner spinnerYear;
    private Spinner spinnerTransmission;
    private Button button, button_skip;
    private SharedPreferences mPrefs,mPrefMain;
    private EditText   modelEditText;
    private AutoCompleteTextView markEditText ;
    private String selectedItemYear;
    private String selectedItemTransmission;
    private DetailVehicule detailVehicule = null;
    private boolean is_from_registration;
    private Users users = null;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Mon Véhicule");

        return inflater.inflate(R.layout.fragment_vehicle, container, false);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        bindViews();

        is_from_registration = getActivity().getIntent().getBooleanExtra("from_registration", false);


        mPrefs = getContext().getSharedPreferences(PREFS_DetailVehicule, MODE_PRIVATE);
        mPrefMain = getContext().getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        Gson gson1 = new Gson();
        String json1 = mPrefMain.getString("user_main_info", "");
        users = gson1.fromJson(json1, Users.class);

        // Get the string array
        String[] countries = getResources().getStringArray(R.array.cars_array);
// Create the adapter and set it to the AutoCompleteTextView
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, countries);
        markEditText.setAdapter(adapter);


        ArrayAdapter<String> ArrayAdapterYear = new ArrayAdapter<String>
                (getContext(), android.R.layout.simple_spinner_item, YearSpinner());

        ArrayAdapter<String> ArrayAdapterTransmission = new ArrayAdapter<String>
                (getContext(), android.R.layout.simple_spinner_item, TransmissionValue());

        ArrayAdapterYear.setDropDownViewResource(R.layout
                .custom_spinner_dropdown_item);
        ArrayAdapterTransmission.setDropDownViewResource(R.layout
                .custom_spinner_dropdown_item);
        spinnerYear.setAdapter(ArrayAdapterYear);
        spinnerTransmission.setAdapter(ArrayAdapterTransmission);

        spinnerYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedItemYear = parent.getItemAtPosition(position).toString();

            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerTransmission.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedItemTransmission = parent.getItemAtPosition(position).toString();

            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        if (detailVehicule == null) {
            Gson gson = new Gson();
            String json = mPrefs.getString("detailvehicule", "");
            detailVehicule = gson.fromJson(json, DetailVehicule.class);
        }

        if (detailVehicule != null) {

            markEditText.setText(detailVehicule.getMark());
            modelEditText.setText(detailVehicule.getModel());
            setSpinText(spinnerYear, detailVehicule.getDate());
            setSpinText(spinnerTransmission, detailVehicule.getTransmission());

//            markEditText.setFocusable(false);
//            modelEditText.setFocusable(false);
//            spinnerYear.setFocusable(false);
//            spinnerTransmission.setFocusable(false);
        }

        if (markEditText.isSelected() == true ||
                modelEditText.isSelected() == true ||
                spinnerYear.isSelected() == true ||
                spinnerTransmission.isSelected() == true) {
            markEditText.setFocusable(true);
            modelEditText.setFocusable(true);
            spinnerYear.setFocusable(true);
            spinnerTransmission.setFocusable(true);
        }


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (markEditText.isFocusable() == true ||
                        modelEditText.isFocusable() == true ||
                        spinnerYear.isFocusable() == true ||
                        spinnerTransmission.isSelected() == true) {
                    button.setEnabled(true);
                    attemptForm();
                }
            }
        });

        button_skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), MenuActivity.class));
            }
        });
        if (is_from_registration){
            button_skip.setVisibility(View.VISIBLE);

            button.setText("Suivant");
        }
    }


    public void setSpinText(Spinner spin, String text) {
        for (int i = 0; i < spin.getAdapter().getCount(); i++) {
            if (spin.getAdapter().getItem(i).toString().contains(text)) {
                spin.setSelection(i);
            }
        }

    }

    private void bindViews() {
        spinnerYear = getView().findViewById(R.id.year_picker);
        spinnerTransmission = getView().findViewById(R.id.transmission);
        button = getView().findViewById(R.id.button_save);
        button_skip = getView().findViewById(R.id.button_skip);
        markEditText =   getView().findViewById(R.id.mark);
        modelEditText = (EditText) getView().findViewById(R.id.model);
    }

    private void attemptForm() {

        markEditText.setError(null);
        modelEditText.setError(null);


        boolean cancel = false;
        View focusView = null;


        if (TextUtils.isEmpty(markEditText.getText().toString())) {
            markEditText.setError(getString(R.string.error_field_required));
            focusView = markEditText;
            cancel = true;
        }

        if (TextUtils.isEmpty(modelEditText.getText().toString())) {
            modelEditText.setError(getString(R.string.error_field_required));
            focusView = modelEditText;
            cancel = true;
        }

        if (TextUtils.isEmpty(markEditText.getText().toString())) {
            markEditText.setError(getString(R.string.error_field_required));
            focusView = markEditText;
            cancel = true;
        }


        if (cancel) {
            focusView.requestFocus();
        } else {

            detailVehicule = new DetailVehicule(markEditText.getText().toString()
                    , modelEditText.getText().toString()
                    , selectedItemYear, selectedItemTransmission);

            if (detailVehicule == null) {

                SharedPreferences.Editor prefsEditor = mPrefs.edit();
                Gson gson = new Gson();
                String json = gson.toJson(detailVehicule);
                prefsEditor.putString("detailvehicule", json);
                prefsEditor.commit();
//                if(is_from_registration)
//                    startActivity(new Intent(getContext(),MenuActivity.class));


            } else {
                getContext().getSharedPreferences(PREFS_DetailVehicule, MODE_PRIVATE).edit().clear().commit();
                mPrefs = getContext().getSharedPreferences(PREFS_DetailVehicule, MODE_PRIVATE);
                SharedPreferences.Editor prefsEditor = mPrefs.edit();
                Gson gson = new Gson();
                String json = gson.toJson(detailVehicule);
                prefsEditor.putString("detailvehicule", json);
                prefsEditor.commit();


                Utils.ToastMsg(getContext(), "Caractéristiques véhicule enregistrées");
                if(is_from_registration)
                    startActivity(new Intent(getContext(),MenuActivity.class));
                else
                {
//                    Intent i = new Intent(getContext(), MainActivity.class);
//                    i.putExtra("map", "map");
//                    getContext().startActivity(i);
                    new getAllMaker(users, getContext()).getAll();

                }


            }


        }
    }
}
