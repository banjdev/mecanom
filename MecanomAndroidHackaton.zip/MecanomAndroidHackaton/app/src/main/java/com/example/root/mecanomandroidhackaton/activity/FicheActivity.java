package com.example.root.mecanomandroidhackaton.activity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.root.mecanomandroidhackaton.model.Users;
import com.google.gson.Gson;

import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;
import com.example.root.mecanomandroidhackaton.R;


public class FicheActivity extends AppCompatActivity {


    private TextView mechanicLabel,markLabel,modelLabel,yearLabel,addressLabel,troubleLabel,phone,email,garageName,garageAddress;
    private Users users = null,  userData = null;
    private SharedPreferences mPrefs ;
    private int driver_id;
    private String userData_json;
    private TableRow row_phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fiche);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        bindViews();



        mPrefs = getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        Gson gson = new Gson();
        String json = mPrefs.getString("user_main_info", "");
        users = gson.fromJson(json, Users.class);
        userData_json = getIntent().getStringExtra("userDriver");
        userData = gson.fromJson(userData_json, Users.class);

        if(userData!=null) {
            initValues(userData);

            if(userData.getIsMechanic() == 0) {
                getSupportActionBar().setTitle(userData.getPseudo());

            }
        }
    }

   private void bindViews(){
       row_phone = findViewById(R.id.row_phone);
       mechanicLabel = findViewById(R.id.mechanic_name);
       garageName = findViewById(R.id.garage_name);
       garageAddress = findViewById(R.id.address_garage);
            markLabel = findViewById(R.id.mark);
            modelLabel = findViewById(R.id.model);
            yearLabel = findViewById(R.id.year_picker);
            addressLabel = findViewById(R.id.adress);
            troubleLabel = findViewById(R.id.trouble);
            phone = findViewById(R.id.phone);
            email = findViewById(R.id.email);
        }

    private void initValues(Users userData) {
        if (userData != null) {
            if(userData.getPhone() == null)
                row_phone.setVisibility(View.GONE);
            else
                phone.setText(userData.getPhone());

            markLabel.setText(userData.getNotifications().getDetailVehicule().getMark());
            modelLabel.setText(userData.getNotifications().getDetailVehicule().getModel());
            yearLabel.setText(String.valueOf(userData.getNotifications().getDetailVehicule().getYear()));
            troubleLabel.setText(userData.getNotifications().getDetailVehicule().getTrouble());
            try {
                addressLabel.setText(userData.getNotifications().getLocations().getAdress());
            }
            catch(Exception e){

            }
            mechanicLabel.setText(userData.getNotifications().getMechanic_name().substring(0,userData.getNotifications().getMechanic_name().indexOf('@')));
            email.setText(userData.getEmail());
            phone.setText(userData.getPhone());
            garageAddress.setText(userData.getNotifications().getGarage_address());
            garageName.setText(userData.getNotifications().getGarage_name());
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
            {
                onBackPressed();
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
