package com.example.root.mecanomandroidhackaton.activity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.root.mecanomandroidhackaton.ControlModel.saveNotifClientMainRequest;
import com.example.root.mecanomandroidhackaton.R;
import com.example.root.mecanomandroidhackaton.model.DetailVehicule;
import com.example.root.mecanomandroidhackaton.model.Locations;
import com.example.root.mecanomandroidhackaton.model.Mechanic;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.example.root.mecanomandroidhackaton.util.Utils.YearSpinner;
import static com.example.root.mecanomandroidhackaton.util.Utils.getRealTime;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_DetailVehicule;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.TransmissionValue;


public class ProfilGaragistActivity extends AppCompatActivity {

    private Button Btn_Contact,sendInfo;
    private Spinner spinnerYear,spinnerTransmission;
    private DetailVehicule detailVehicule,detailVehicule_save = null;
    private EditText markEditText,modelEditText,troubleEditText;
    private int selectedItemYear;
    private String selectedItemTransmission;
    private TextView adress,phone,name,email,availability,garage_name ;
    private RatingBar ratingBar;
    private SharedPreferences mPrefs,mPrefsL,mPrefD;
    private RecyclerView rv;
    private Users userDriver = new Users();
    private Mechanic userMechanic = new Mechanic();
    private String userMechanic_json;
    private Locations locations = null;
    private boolean showprofil = true;
    private String detailVehicule_json;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_garagist);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bindViews();

        mPrefs = getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        Gson gson = new Gson();

        userMechanic_json = getIntent().getStringExtra("userMechanic");
        userMechanic = gson.fromJson(userMechanic_json, Mechanic.class);

//        detailVehicule_json = getIntent().getStringExtra("detailVehicule_save");

//        detailVehicule_save = gson.fromJson(detailVehicule_json, DetailVehicule.class);
        showprofil = getIntent().getBooleanExtra("showprofil",false);


        String json = mPrefs.getString("user_main_info", "");
        userDriver = gson.fromJson(json, Users.class);

        if(detailVehicule == null){
            mPrefD = getSharedPreferences(PREFS_DetailVehicule,MODE_PRIVATE);


            json = mPrefD.getString("detailvehicule", "");

            detailVehicule = gson.fromJson(json, DetailVehicule.class);
        }




        initValues(userMechanic);

        Btn_Contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialodDetailVehicule(detailVehicule);

            }
        });



    }

    private void dialodDetailVehicule(final DetailVehicule  detailVehicule) {
        LayoutInflater inflater1 = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater1.inflate(R.layout.layout_detail_vehicule, null);
        if (layout.getParent() != null)
            ((ViewGroup) layout.getParent()).removeView(layout);


        final AlertDialog alertDialog = new AlertDialog.Builder(ProfilGaragistActivity.this).create();
        alertDialog.setView(layout);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        final ImageButton Btn_Close = layout.findViewById(R.id.btn_close);
        sendInfo = layout.findViewById(R.id.btn_send);
        markEditText = (EditText) layout.findViewById(R.id.mark);
        modelEditText = (EditText) layout.findViewById(R.id.model);
        troubleEditText = (EditText) layout.findViewById(R.id.trouble);


        spinnerYear = layout.findViewById(R.id.year_picker);
        spinnerTransmission = layout.findViewById(R.id.transmission);

        if(!showprofil){
            sendInfo.setText("Confirmer");
        }


        ArrayAdapter<String> ArrayAdapterYear = new ArrayAdapter<String>
                (ProfilGaragistActivity.this, android.R.layout.simple_spinner_item, YearSpinner());

        ArrayAdapterYear.setDropDownViewResource(R.layout
                .custom_spinner_dropdown_item);
        spinnerYear.setAdapter(ArrayAdapterYear);


        ArrayAdapter<String> ArrayAdapterTransmission = new ArrayAdapter<String>
                (ProfilGaragistActivity.this, android.R.layout.simple_spinner_item, TransmissionValue());

        ArrayAdapterTransmission.setDropDownViewResource(R.layout
                .custom_spinner_dropdown_item);
        spinnerTransmission.setAdapter(ArrayAdapterTransmission);

        spinnerYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                selectedItemYear = Integer.parseInt(parent.getItemAtPosition(position).toString());

            }
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

        spinnerTransmission.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                selectedItemTransmission = parent.getItemAtPosition(position).toString();

            }
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

        if(detailVehicule != null){

            markEditText.setText(detailVehicule.getMark());
            modelEditText.setText(detailVehicule.getModel());
            setSpinText(spinnerYear,detailVehicule.getDate());
            setSpinText(spinnerTransmission,detailVehicule.getTransmission());
        }

        alertDialog.show();

        Btn_Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        sendInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptForm(alertDialog);

            }
        });
    }

    private void attemptForm(AlertDialog alertDialog){

        troubleEditText.setError(null);


        boolean cancel = false;
        View focusView = null;



        if (TextUtils.isEmpty(troubleEditText.getText().toString())) {
            troubleEditText.setError(getString(R.string.error_field_required));
            focusView = troubleEditText;
            cancel = true;
        }





        if (cancel) {
            focusView.requestFocus();
        } else {


            //                detailVehicule = new DetailVehicule(markEditText.getText().toString()
//                        ,modelEditText.getText().toString()
//                        , selectedItemYear,selectedItemTransmission,troubleEditText.getText().toString());
            DetailVehicule detailVehicule1 = new DetailVehicule();

            detailVehicule1.setMark(markEditText.getText().toString());
            detailVehicule1.setModel(modelEditText.getText().toString());
            detailVehicule1.setTransmission(selectedItemTransmission);
            detailVehicule1.setYear(selectedItemYear);

            detailVehicule1.setTrouble(troubleEditText.getText().toString());
            detailVehicule1.setDate(getRealTime());
//                        userDriver = new Users();

//                        progressDialog.setMessage("say ");

//                        startActivity(new Intent(ProfilGaragistActivity.this,RequestClientActivity.class).putExtra("detailVehicule",detailVehicule));
            if (Utils.isIntenetAvailavle(ProfilGaragistActivity.this))
                new saveNotifClientMainRequest(userDriver,userMechanic,  ProfilGaragistActivity.this,detailVehicule1).sendIt();
            else
                Utils.ToastMsg(ProfilGaragistActivity.this,"verifiez votre connection,reessayez");
            alertDialog.dismiss();


        }
    }

    private void initValues(Mechanic userMechanic) {
        if(userMechanic != null){

//            availability.setText(userMechanic.getAvailability());
//            email.setText(userMechanic.getUser().getEmail());
            name.setText(userMechanic.getUser().getEmail().substring(0,userMechanic.getUser().getEmail().indexOf('@')));
            garage_name.setText(userMechanic.getGarage().getName());
            ratingBar.setRating(userMechanic.getUser().getRating());
//            phone.setText(userMechanic.getUser().getPhone());
            adress.setText(userMechanic.getUser().getLocations().getAdress());

            String[] servicesValues = new String[] { "Bouchine",
                    "Shock",
                    "Transmission",
                    "Frein",
                    "Caoutchouc",
                    "Electrique"
            };

            JSONObject servicesJsonO = null;
            try {
                if(userMechanic.getServices() != null) {
                    servicesJsonO = new JSONObject(userMechanic.getServices());

                    JSONArray servicesJsonA = servicesJsonO.getJSONArray("services");
                    for (int i = 0; i < servicesJsonA.length(); i++) {
                        servicesValues[i] = servicesJsonA.getString(i);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }


//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
//                android.R.layout.simple_list_item_1, android.R.mechanic_id.text1, values);

//            rv.setLayoutManager(new LinearLayoutManager(this));
            // Assign adapter to ListView
//            rv.setAdapter(new RecyclerLikeList(servicesValues));

        }

    }




    private void bindViews(){

        Btn_Contact = findViewById(R.id.btn_contact);
//        rv = (RecyclerView)findViewById(R.id.list);
        adress = (TextView) findViewById(R.id.adress);
//        phone = (TextView) findViewById(R.id.phone);
//        email = (TextView) findViewById(R.id.email);
        availability = (TextView) findViewById(R.id.availability);
        name = (TextView) findViewById(R.id.mechanic_name);
        garage_name = (TextView) findViewById(R.id.garage_name);
        ratingBar = findViewById(R.id.rate);
    }

    public void setSpinText(Spinner spin, String text)
    {
        for(int i= 0; i < spin.getAdapter().getCount(); i++)
        {
            if(spin.getAdapter().getItem(i).toString().contains(text))
            {
                spin.setSelection(i);
            }
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
            {
                onBackPressed();
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
