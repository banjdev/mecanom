package com.example.root.mecanomandroidhackaton.activity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.root.mecanomandroidhackaton.ControlModel.getAllMaker;
import com.example.root.mecanomandroidhackaton.model.DetailVehicule;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.google.gson.Gson;

import static com.example.root.mecanomandroidhackaton.util.Utils.YearSpinner;
import static com.example.root.mecanomandroidhackaton.util.Utils.getRealTime;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_DetailVehicule;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.TransmissionValue;
import com.example.root.mecanomandroidhackaton.R;



public class FormRequestActivity extends AppCompatActivity {

    private Spinner spinnerYear,spinnerTransmission;
    private DetailVehicule detailVehicule = null;
    private EditText markEditText,modelEditText ;
    private int selectedItemYear;
    private String selectedItemTransmission;
    private SharedPreferences mPrefs,mPrefsL,mPrefD;
    private RecyclerView rv;
    private Users userMechanic,userDriver = new Users();
    private String userMechanic_json;
    private Button sendInfo;
    private Users users = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_request);

        getSupportActionBar().setTitle("Mon Véhicule");
        bindViews();

        mPrefs = getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        Gson gson = new Gson();
        String json = mPrefs.getString("user_main_info", "");
        users = gson.fromJson(json, Users.class);

        if(detailVehicule == null){
            mPrefD = getSharedPreferences(PREFS_DetailVehicule,MODE_PRIVATE);

            json = mPrefD.getString("detailvehicule", "");
            detailVehicule = gson.fromJson(json, DetailVehicule.class);
        }

        initValues();
        setListener();
    }

    private void bindViews(){
        sendInfo = findViewById(R.id.button_save);
        markEditText = (EditText)  findViewById(R.id.mark);
        modelEditText = (EditText) findViewById(R.id.model);
//        troubleEditText = (EditText) findViewById(R.id.trouble);

        spinnerYear = findViewById(R.id.year_picker);
        spinnerTransmission = findViewById(R.id.transmission);

    }

    private void setListener(){
        sendInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                detailVehicule = new DetailVehicule(markEditText.getText().toString()
                        ,modelEditText.getText().toString()
                        , selectedItemYear,selectedItemTransmission );

                detailVehicule.setDate(getRealTime());


//                Gson gson = new Gson();
//                String json = gson.toJson(detailVehicule);

                getSharedPreferences(PREFS_DetailVehicule,MODE_PRIVATE).edit().clear().commit();
                mPrefD = getSharedPreferences(PREFS_DetailVehicule,MODE_PRIVATE);
                SharedPreferences.Editor prefsEditor = mPrefD.edit();
                Gson gson = new Gson();
                String json = gson.toJson(detailVehicule);
                prefsEditor.putString("detailvehicule", json);
                prefsEditor.commit();

                new getAllMaker(users,  FormRequestActivity.this).getAll();

//                        startActivity(new Intent(ProfilGaragistActivity.this,RequestClientActivity.class).putExtra("detailVehicule",detailVehicule));

            }
        });
    }

    private void initValues(){

        ArrayAdapter<String> ArrayAdapterYear = new ArrayAdapter<String>
                (FormRequestActivity.this, android.R.layout.simple_spinner_item, YearSpinner());

        ArrayAdapterYear.setDropDownViewResource(R.layout
                .custom_spinner_dropdown_item);
        spinnerYear.setAdapter(ArrayAdapterYear);


        ArrayAdapter<String> ArrayAdapterTransmission = new ArrayAdapter<String>
                (FormRequestActivity.this, android.R.layout.simple_spinner_item, TransmissionValue());

        ArrayAdapterTransmission.setDropDownViewResource(R.layout
                .custom_spinner_dropdown_item);
        spinnerTransmission.setAdapter(ArrayAdapterTransmission);

        spinnerYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                selectedItemYear = Integer.parseInt(parent.getItemAtPosition(position).toString());

            }
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

        spinnerTransmission.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                selectedItemTransmission = parent.getItemAtPosition(position).toString();

            }
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

        if(detailVehicule != null){

            markEditText.setText(detailVehicule.getMark());
            modelEditText.setText(detailVehicule.getModel());
            setSpinText(spinnerYear,detailVehicule.getDate());
            setSpinText(spinnerTransmission,detailVehicule.getTransmission());
        }

    }

    public void setSpinText(Spinner spin, String text)
    {
        for(int i= 0; i < spin.getAdapter().getCount(); i++)
        {
            if(spin.getAdapter().getItem(i).toString().contains(text))
            {
                spin.setSelection(i);
            }
        }

    }
}
