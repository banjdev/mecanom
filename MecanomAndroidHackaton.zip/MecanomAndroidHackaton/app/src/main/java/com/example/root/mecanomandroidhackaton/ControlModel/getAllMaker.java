package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.activity.MainActivity;
import com.example.root.mecanomandroidhackaton.model.Mechanic;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.saveMechanicList;



public class getAllMaker {
    private Users users = null;
    private Context context;
    private String token;
    List<Mechanic> mechanicList = new ArrayList<Mechanic>();
    private int fromConnect = 0;
    private ProgressDialog progressDialog;
    private String json;
    private String detailVehicule_json = null;


    public getAllMaker(Users users) {
        this.users = users;
    }

    public getAllMaker(Users users, Context context) {
        this.users = users;
        this.context = context;
    }

    public getAllMaker(Users users, int fromConnect, Context context) {
        this.users = users;
        this.fromConnect = fromConnect;
        this.context = context;
    }

    public getAllMaker(Users users, int fromConnect, Context context, String detailVehicule_json) {
        this.users = users;
        this.fromConnect = fromConnect;
        this.context = context;
        this.detailVehicule_json = detailVehicule_json;
    }

    public void getAll() {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Geolocalisation de nos agents ...");
        progressDialog.show();

        ApiService service = getApiService();
        token = "Bearer " + users.getToken();
        Call<List<Mechanic>> call = service.getAllMaker(token);

        call.enqueue(new Callback<List<Mechanic>>() {
            @Override
            public void onResponse(Call<List<Mechanic>> call, Response<List<Mechanic>> response) {
                Log.i("Halla", "" + response);
                if (response.code() == 200) {
                    mechanicList = response.body();
                    System.out.println("fresh listmeka" + mechanicList);

                    saveMechanicList(mechanicList, context);
                    Gson gson = new Gson();
                    json = gson.toJson(mechanicList, new TypeToken<List<Mechanic>>() {
                    }.getType());
                    progressDialog.dismiss();
                    Intent intent = new Intent(context, MainActivity.class);
                    intent.putExtra("mechanicList", json);
                    intent.putExtra("map", "map");
                    context.startActivity(intent);

                } else {
                    mechanicList = null;
                    progressDialog.dismiss();
                    Intent intent = new Intent(context, MainActivity.class);
                    intent.putExtra("mechanicList", json);
                    intent.putExtra("map", "map");

                    context.startActivity(intent);


                }

            }

            @Override
            public void onFailure(Call<List<Mechanic>> call, Throwable t) {
                Log.i("Hello", "" + t);
                mechanicList = null;
                progressDialog.dismiss();

                Intent intent = new Intent(context, MainActivity.class);
                intent.putExtra("mechanicList", json);
                intent.putExtra("map", "map");

                context.startActivity(intent);

            }
        });

    }

}
