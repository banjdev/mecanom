package com.example.root.mecanomandroidhackaton.model;




import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Users implements Parcelable
{

    @SerializedName("id")
    @Expose
    private int id;
    @SerializedName("ismechanic")
    @Expose
    private int isMechanic = 0;

    @SerializedName("location_id")
    @Expose
    private int location_id = 0;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("name")
    @Expose
    private String pseudo;
    @SerializedName("phone")
    @Expose
    private String phone;
    @SerializedName("availability")
    @Expose
    private String availability;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("token")
    @Expose
    private String token;
    @SerializedName("services")
    @Expose
    private String services;
    @SerializedName("fbtoken")
    @Expose
    private String fbtoken;
    @SerializedName("remember_token")
    @Expose
    private String rememberToken;
    @SerializedName("detailVehicule")
    @Expose
    private DetailVehicule detailVehicule;
    @SerializedName("rating")
    @Expose
    private float rating;
    @SerializedName("location")
    @Expose
    private Locations locations;


    @SerializedName("notifications")
    @Expose
    private Notifications notifications;


    public final static Creator<Users> CREATOR = new Creator<Users>() {


        @SuppressWarnings({
                "unchecked"
        })
        public Users createFromParcel(Parcel in) {
            Users instance = new Users();
            instance.id = ((int) in.readValue((int.class.getClassLoader())));
            instance.isMechanic = ((int) in.readValue((int.class.getClassLoader())));
            instance.location_id = ((int) in.readValue((int.class.getClassLoader())));
            instance.email = ((String) in.readValue((String.class.getClassLoader())));
            instance.pseudo = ((String) in.readValue((String.class.getClassLoader())));
            instance.phone = ((String) in.readValue((String.class.getClassLoader())));
            instance.availability = ((String) in.readValue((String.class.getClassLoader())));
            instance.password = ((String) in.readValue((String.class.getClassLoader())));
            instance.services = ((String) in.readValue((String.class.getClassLoader())));
            instance.rating = ((float) in.readValue((float.class.getClassLoader())));
            instance.token = ((String) in.readValue((String.class.getClassLoader())));
            instance.fbtoken = ((String) in.readValue((String.class.getClassLoader())));
            instance.rememberToken = ((String) in.readValue((String.class.getClassLoader())));
            instance.detailVehicule = ((DetailVehicule) in.readValue((DetailVehicule.class.getClassLoader())));
            instance.locations = ((Locations) in.readValue((Locations.class.getClassLoader())));
            instance.notifications = ((Notifications) in.readValue((Locations.class.getClassLoader())));



            return instance;
        }

        public Users[] newArray(int size) {
            return (new Users[size]);
        }

    }
            ;



    public Users() {
    }




    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIsMechanic() {
        return isMechanic;
    }

    public void setIsMechanic(int isMechanic) {
        this.isMechanic = isMechanic;
    }

    public int getLocation_id() {
        return location_id;
    }

    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPseudo() {
        return pseudo;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }


    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }



    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRememberToken() {
        return rememberToken;
    }

    public void setRememberToken(String rememberToken) {
        this.rememberToken = rememberToken;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
    public String getFbtoken() {
        return fbtoken;
    }

    public void setFbtoken(String fbtoken) {
        this.fbtoken = fbtoken;
    }

    public DetailVehicule getDetailVehicule() {
        return detailVehicule;
    }

    public void setDetailVehicule(DetailVehicule detailVehicule) {
        this.detailVehicule = detailVehicule;
    }

    public Locations getLocations() {
        return locations;
    }

    public void setLocations(Locations locations) {
        this.locations = locations;
    }

    public String getServices() {
        return services;
    }

    public void setServices(String services) {
        this.services = services;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }



    public Notifications getNotifications() {
        return notifications;
    }

    public void setNotifications(Notifications notifications) {
        this.notifications = notifications;
    }
     @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                "location_id='" + location_id + '\'' +
                ", email='" + email + '\'' +
                ", pseudo='" + pseudo + '\'' +
                ", phone='" + phone + '\'' +
                ", availability='" + availability + '\'' +
                ", password='" + password + '\'' +
                ", services='" + services + '\'' +
                ", rating='" + rating + '\'' +
                ", token='" + token + '\'' +
                ", detailVehicule='" + detailVehicule + '\'' +
                ", location='" + locations + '\'' +
                ", notifications='" + notifications + '\'' +

                ", fbtoken='" + fbtoken + '\'' +
                ", rememberToken='" + rememberToken + '\'' +
                '}';
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(location_id);
        dest.writeValue(email);
        dest.writeValue(phone);
        dest.writeValue(availability);
        dest.writeValue(password);
        dest.writeValue(services);

        dest.writeValue(rememberToken);
        dest.writeValue(token);
        dest.writeValue(fbtoken);
        dest.writeValue(detailVehicule);
        dest.writeValue(locations);
        dest.writeValue(notifications);
        dest.writeValue(rating);
    }

    public int describeContents() {
        return 0;
    }
}

