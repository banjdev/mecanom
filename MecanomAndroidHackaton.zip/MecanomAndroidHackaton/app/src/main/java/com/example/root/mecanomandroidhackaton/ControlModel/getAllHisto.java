package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.adapter.HistoryAdapter;
import com.example.root.mecanomandroidhackaton.model.Notifications;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;



public class getAllHisto {
    private Users users = null;
    private Context context ;
    private String token;
    List<Notifications> notifications = new ArrayList<Notifications>();
    private HistoryAdapter historyAdapter;
    private boolean haveNotif = false;


    public getAllHisto(Users users, Context context, HistoryAdapter historyAdapter ) {
        this.users = users;
        this.context = context;
        this.historyAdapter = historyAdapter;

    }

    public boolean getAll( ) {


        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("un instant ...");
        progressDialog.show();

        ApiService service = getApiService();
        token = "Bearer " + users.getToken();
        Call<List<Notifications>> call = service.getAllHisto(token,users.getId(),users.getIsMechanic() );
        Log.i("Halla", "" + users.getId()+""+users.getIsMechanic());

        call.enqueue(new Callback<List<Notifications>>() {
            @Override
            public void onResponse(Call<List<Notifications>> call, Response<List<Notifications>> response) {
                Log.i("Halla", "" + response);
                if (response.code() == 200) {
                    haveNotif = true;
                    notifications = response.body();
                    if (notifications.size() != 0) {

                        List<Notifications> notificationsAfter = new ArrayList<>();
                         if(users.getIsMechanic() == 0) {
                             int i = 0;
                            while (i < notifications.size()) {
                                if (notifications.get(i).getPrincipal_id() == users.getId()) {
                                    notifications.remove(i);
                                 } else {
                                    if(notifications.get(i).getDriver_id() == users.getId()) {
                                        notificationsAfter.add(notifications.get(i));
                                        System.out.println("notif ajouter"+notifications.get(i));
                                    }
                                }
                                i++;
                            }
                        }
                        else{

                            int i = 0;
                            while (i < notifications.size()) {
                                if (notifications.get(i).getPrincipal_id() != users.getId()) {
                                    notifications.remove(i);

                                } else {
                                    notificationsAfter.add(notifications.get(i) );


                                }
                                i++;
                            }
                        }

                        historyAdapter.setItems(notificationsAfter);

                    }
                    else {
                        Utils.ToastMsg(context,"pas d historqiue disponible");

                        historyAdapter.setItems(notifications);
                    }
//                    ((Activity)context).findViewById(R.id.loadingPanel).setVisibility(View.GONE);


                } else {
                    notifications = null;
                    Utils.ToastMsg(context,"erreur de connexion1,reesayez");

                }
                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<List<Notifications>> call, Throwable t) {
                Log.i("Hello", "" + t);
                notifications = null;
                progressDialog.dismiss();
                Utils.ToastMsg(context,"erreur de connexion2,reesayez");
//                ((Activity)context).findViewById(R.id.loadingPanel).setVisibility(View.GONE);
            }
        });

        return haveNotif;
    }
}
