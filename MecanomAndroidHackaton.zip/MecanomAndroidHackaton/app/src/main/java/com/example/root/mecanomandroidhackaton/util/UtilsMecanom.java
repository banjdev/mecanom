package com.example.root.mecanomandroidhackaton.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.example.root.mecanomandroidhackaton.App;
import com.example.root.mecanomandroidhackaton.ControlModel.ApiService;
import com.example.root.mecanomandroidhackaton.model.Mechanic;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Destin Moise  .
 *
  */

public class UtilsMecanom {

//    public static final String Constant_url="http://66.42.84.103/";
    public static final String Constant_url="http://192.168.1.225:8000/";

     public static final String Constant_urlfb="https://fcm.googleapis.com/fcm/";
    public static final String PREFS_USER_Main = "UserData";
    public static final String PREFS_USER_All = "AllUserData";

    public static final String PREFS_LOCATION = "LocationData";
    public static final String PREFS_DetailVehicule = "DetailVehiculeData";
    public static final String PREFS_HIDE_DIALOG = "HIDE_DIALOG ";
    public static final String PREFS_INFO = "Info ";
    public static final String fbkey = "AAAAv1r4rVo:APA91bGegIMyOQapHwCKiPa8bXkgYnKa4mZc_LlVfkJbIdTe8nWO8qWXX1lUnmNvnGSto6_xsWOaE_1a2n1i1DwMt2-6cjYi9FmRSVzOSs3UC5VKQHGNtVOUMXne9bXZ4_j4-VfWyali";

    public static ApiService getApiService() {
        OkHttpClient client = new OkHttpClient();
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constant_url)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        return retrofit.create(ApiService.class);
    }

    public static ApiService getApiServiceFb() {
        OkHttpClient client = new OkHttpClient();
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constant_urlfb)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        return retrofit.create(ApiService.class);
    }

    public static void saveUserMainInfo(Users users, Context context){

        SharedPreferences mPrefs =  context.getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = mPrefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(users);
        prefsEditor.putString("user_main_info", json);
        prefsEditor.commit();

    }

    public static void saveMechanicList(List<Mechanic> mechanicList, Context context){

        Type listType = new TypeToken<List<Mechanic>>() {}.getType();
        SharedPreferences mPrefs =  PreferenceManager.getDefaultSharedPreferences(App.getAppContext());
        SharedPreferences.Editor prefsEditor = mPrefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(mechanicList,listType);
        prefsEditor.putString("mechaniclist", json);
        prefsEditor.commit();

    }

    public static void saveFbToken(String fbtoken, Context context){

        SharedPreferences mPrefs =  context.getSharedPreferences(PREFS_LOCATION,MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = mPrefs.edit();
        prefsEditor.putString("fbtoken", fbtoken);
        prefsEditor.commit();

    }

    public static void saveLoggedIN(Context context){
        SharedPreferences sharedPreferences=  context.getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        SharedPreferences.Editor editor= sharedPreferences.edit();
        editor.putBoolean("LOGGED", true);
        editor.apply();
    }
    public static void saveLoggedout(Context context){
        SharedPreferences sharedPreferences=  context.getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        SharedPreferences.Editor editor= sharedPreferences.edit();
        editor.putBoolean("LOGGED", false);
        editor.apply();
    }

    public static boolean isLoggedIn(Context context){
        try {
            SharedPreferences sharedPreferences =  context.getSharedPreferences(PREFS_USER_Main, MODE_PRIVATE);
            return sharedPreferences.getBoolean("LOGGED",false);
        }
        catch(Exception e){
            return false;
        }
    }



    public static ArrayList<String> TransmissionValue() {
        ArrayList<String> listTransmission = new ArrayList<>();

            listTransmission.add("automatique");
            listTransmission.add("manuelle");
        return listTransmission;
    }


    public static ArrayList<String> QtifyValue() {
        ArrayList<String> QtifyValueList = new ArrayList<>();

        QtifyValueList.add("hr");
        QtifyValueList.add("min");
        return QtifyValueList;
    }
    public static List ReverseArrayList(List val){
        List formModelsWithoutDoublet = new ArrayList<>();

        Collections.reverse(val);
        return val;
    }

}
