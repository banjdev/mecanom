package com.example.root.mecanomandroidhackaton.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.root.mecanomandroidhackaton.ControlModel.CustomRegistration;
import com.example.root.mecanomandroidhackaton.DestinMLogin.LoginType;
import com.example.root.mecanomandroidhackaton.DestinMLogin.SmartLogin;
import com.example.root.mecanomandroidhackaton.DestinMLogin.SmartLoginCallbacks;
import com.example.root.mecanomandroidhackaton.DestinMLogin.SmartLoginConfig;
import com.example.root.mecanomandroidhackaton.DestinMLogin.SmartLoginFactory;
import com.example.root.mecanomandroidhackaton.DestinMLogin.UserSessionManager;
import com.example.root.mecanomandroidhackaton.DestinMLogin.util.SmartLoginException;
import com.example.root.mecanomandroidhackaton.R;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.GPSTracker;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.gson.Gson;

import static com.example.root.mecanomandroidhackaton.activity.MainActivity.MY_PERMISSIONS_REQUEST_LOCATION;
import static com.example.root.mecanomandroidhackaton.util.Utils.getDouble;
import static com.example.root.mecanomandroidhackaton.util.Utils.putDouble;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_LOCATION;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;

public class RegisterActivity extends AppCompatActivity  implements SmartLoginCallbacks {

    private Button facebookLoginButton, googleLoginButton, customSigninButton, customSignupButton, logoutButton;
    private EditText emailEditText, passwordEditText;
    private Users currentUser;
    //GoogleApiClient mGoogleApiClient;
    private SmartLoginConfig config;
    private SmartLogin smartLogin;
    private GPSTracker gps;
    private double longitude = 0.0, latittude= 0.0;
    private SharedPreferences  mPrefsL;
    private TextView _loginLink;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        bindViews();
        setListeners();

        if (!(Utils.isIntenetAvailavle(this)))
            Utils.ToastMsg(this,"activer la connection internet");

        mPrefsL = getSharedPreferences(PREFS_LOCATION, MODE_PRIVATE);
        gps = new GPSTracker(RegisterActivity.this);
        longitude = getDouble(mPrefsL, "longitude", 0.0);
        latittude = getDouble(mPrefsL, "latittude", 0.0);


        config = new SmartLoginConfig(this, this);

        if (longitude == 0.0 && latittude == 0.0) {
            if (gps.canGetLocation()) {
                ReqPermission();

            } else {

                gps.showSettingsAlert().setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        final Snackbar snackbarP;

                        snackbarP = Snackbar.make(findViewById(android.R.id.content), getResources().getString(R.string.msg_permission), Snackbar.LENGTH_INDEFINITE);
                        snackbarP.setAction("ok", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                snackbarP.dismiss();
                                ReqPermission();
                            }
                        }).show();

                        startActivity(intent);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        final Snackbar snackbarP;

                        snackbarP = Snackbar.make(findViewById(android.R.id.content), getResources().getString(R.string.msg_permission), Snackbar.LENGTH_INDEFINITE);
                        snackbarP.setAction("ok", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                snackbarP.dismiss();
                                ReqPermission();
                            }
                        }).show();

                        startActivity(intent);
                    }
                });


            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (GPSTracker.IsIntentLocation==true) {

            ReqPermission();

        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        smartLogin.onActivityResult(requestCode, resultCode, data, config);


    }


    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        Users users = null;
        SharedPreferences mPrefs;
        mPrefs = getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        String json = mPrefs.getString("user_main_info", "");
        Gson gson = new Gson();
        users = gson.fromJson(json, Users.class);
        if(users == null){
            this.finishAffinity();
        }

    }

    private void setListeners() {



        _loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the registration screen and return to the Login activity
                finish();
            }
        });

        customSignupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptForm("signup");
            }
        });


    }

    private void attemptForm(String type){

        emailEditText.setError(null);
        passwordEditText.setError(null);

        boolean cancel = false;
        View focusView = null;


        if (TextUtils.isEmpty(emailEditText.getText().toString())) {
            emailEditText.setError(getString(R.string.error_field_required));
            focusView = emailEditText;
            cancel = true;
        }

        if (!(emailEditText.getText().toString().contains("@"))) {
            emailEditText.setError("email invalide");
            focusView = emailEditText;
            cancel = true;
        }

        if (TextUtils.isEmpty(passwordEditText.getText().toString())) {
            passwordEditText.setError(getString(R.string.error_field_required));
            focusView = passwordEditText;
            cancel = true;
        }


        if (passwordEditText.getText().toString().length() <4) {
            passwordEditText.setError("choisir un password avec plus de 4 characteres");
            focusView = passwordEditText;
            cancel = true;
        }


        if (cancel) {
            focusView.requestFocus();
        } else {

            if (type.equals("signup")){
                smartLogin = SmartLoginFactory.build(LoginType.CustomLogin);
                smartLogin.signup(config);
                currentUser = UserSessionManager.getCurrentUser(this);


                new Handler().postDelayed(
                        new Runnable() {
                            @Override
                            public void run() {
                                if (Utils.isIntenetAvailavle(RegisterActivity.this))
                                    new CustomRegistration(currentUser,RegisterActivity.this).InsertInfo();
                                else
                                    Utils.ToastMsg(RegisterActivity.this,"verifiez votre connection,reessayez");
                            }
                        },
                        100
                );
            }

        }
    }

    private void bindViews() {

        customSignupButton = (Button) findViewById(R.id.btn_signup);
        emailEditText = (EditText) findViewById(R.id.input_email);
        passwordEditText = (EditText) findViewById(R.id.input_password);
        _loginLink =   findViewById(R.id.link_login);
        _loginLink.setPaintFlags(_loginLink.getPaintFlags() |   Paint.UNDERLINE_TEXT_FLAG);

    }
    @Override
    public void onLoginSuccess(Users user) {
//        Toast.makeText(this, user.toString(), Toast.LENGTH_SHORT).show();
//        refreshLayout();
    }


    @Override
    public void onLoginFailure(SmartLoginException e) {
//        Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
    }



    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public Users doCustomLogin() {
        Users user = new Users();
        user.setEmail(emailEditText.getText().toString());
        user.setPassword(passwordEditText.getText().toString());

        return user;
    }

    @Override
    public Users doCustomSignup() {
        Users user = new Users();
        user.setEmail(emailEditText.getText().toString());
        user.setPassword(passwordEditText.getText().toString());
        return user;
    }


    private void ReqPermission() {
        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                System.out.println("need explanation");
                new AlertDialog.Builder(this)
                        .setTitle("location")
                        .setMessage("we need your location to show you your location on the map")
                        .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(RegisterActivity.this,
                                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();

            } else {

                // No explanation needed, we can request the permission.
                System.out.println("call permission");
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }

        else{
            SearchingForLocation();
        }
    }

    private void SearchingForLocation() {

        if(gps.canGetLocation()) {
            Utils.ToastMsg(this, "localisation en cours");

            Thread thread = new Thread() {
                @Override
                public void run() {
                    int time = 0;
                    System.out.println("inside thread");
                    while (gps.getLocation() == null) {
                        if (time < 6) {
                            System.out.println("boucle if");
                            try {
                                Thread.sleep(9000);
                                gps = new GPSTracker(RegisterActivity.this);

                                time++;
                            } catch (InterruptedException e) {
//                            e.printStackTrace();
                                System.out.println(e.getMessage());
                            }
                        } else
                            break;
                    }
                }

            };

            thread.start();


            if (gps.getLocation() != null) {
                longitude = gps.getLongitude();
                latittude = gps.getLatitude();
                if (longitude != 0.0 && latittude != 0.0) {

                    Utils.clearSharedPreferences(this);
                    SharedPreferences.Editor prefsEditor = mPrefsL.edit();


                    System.out.println("check error1");
                    putDouble(prefsEditor, "longitude", longitude);
                    putDouble(prefsEditor, "latittude", latittude);
                    prefsEditor.commit();

                } else {

                }

            } else {

            }
        }
    }



    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            android.Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        SearchingForLocation();

                    }

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.


                }
                return;
            }

        }
    }
}
