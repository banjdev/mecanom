package com.example.root.mecanomandroidhackaton.DestinMLogin.users;//package com.example.root.kopilot_android.DestinMLogin.users;
//
//import com.example.root.kopilot_android.model.Users;
//import com.facebook.AccessToken;
//
///**
// * Copyright (c) 2016 Codelight Studios
// * Created by Kalyan on 9/23/2015.
// */
//public class SmartFacebookUser extends Users {
//    private String profileName;
//    private AccessToken accessToken;
//    private String birthday;
//    private int gender;
//    private String profileLink;
//    private String firstName;
//    private String middleName;
//    private String lastName;
//
//    public SmartFacebookUser() {
//    }
//
//    public String getProfileName() {
//        return profileName;
//    }
//
//    public void setProfileName(String profileName) {
//        this.profileName = profileName;
//    }
//
//    public AccessToken getAccessToken() {
//        return accessToken;
//    }
//
//    public void setAccessToken(AccessToken accessToken) {
//        this.accessToken = accessToken;
//    }
//
//    public String getBirthday() {
//        return birthday;
//    }
//
//    public void setBirthday(String birthday) {
//        this.birthday = birthday;
//    }
//
//    public int getGender() {
//        return gender;
//    }
//
//    public void setGender(int gender) {
//        this.gender = gender;
//    }
//
//    public String getProfileLink() {
//        return profileLink;
//    }
//
//    public void setProfileLink(String profileLink) {
//        this.profileLink = profileLink;
//    }
//
//    public String getFirstName() {
//        return firstName;
//    }
//
//    public void setFirstName(String firstName) {
//        this.firstName = firstName;
//    }
//
//    public String getLastName() {
//        return lastName;
//    }
//
//    public void setLastName(String lastName) {
//        this.lastName = lastName;
//    }
//
//    public String getMiddleName() {
//        return middleName;
//    }
//
//    public void setMiddleName(String middleName) {
//        this.middleName = middleName;
//    }
//}
