package com.example.root.mecanomandroidhackaton.ControlModel;


import com.example.root.mecanomandroidhackaton.model.Mechanic;
import com.example.root.mecanomandroidhackaton.model.Notifications;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;



public interface ApiService {


    @POST("api/login")
    Call<Users> loginE(@Query("email") String email, @Query("password") String password, @Query("fbtoken") String fbtoken);


    @Headers({ "Accept: application/json"})
//    Call<Users> insertDataE(@Body Users users);
    @FormUrlEncoded
    @POST("api/register")
    Call<Users> insertDataE(@Field("email") String email, @Field("password") String password, @Query("fbtoken") String fbtoken);

    @Headers({ "Accept: application/json"})
    @FormUrlEncoded
    @POST("api/refreshfbtoken")
    Call<Void> refreshFbToken(@Header("Authorization") String authorization, @Field("id") int id, @Field("fbtoken") String fbtoken);

    @POST("api/getAllMaker")
    Call<List<Mechanic>> getAllMaker(@Header("Authorization") String authorization );

    @Headers({ "Accept: application/json"})
    @POST("api/sendMechanicLocation")
    Call<Void> sendMechanicLocation(@Header("Authorization") String authorization , @Body HashMap<String,Object> location );

    @Headers({ "Accept: application/json"})
    @POST("api/changeMechanicLocation")
    Call<Void> changeMechanicLocation(@Header("Authorization") String authorization , @Body HashMap<String,Object> location );

    @Headers({ "Accept: application/json"})
    @POST("api/saveNotifClientMainRequest")
    Call<Void> sendInfoToMechanician(@Header("Authorization") String authorization , @Body HashMap<String,Object> userDriver );

    @Headers({ "Content-Type: application/json"})
    @POST("send")
    Call<Void> sendFbNotif(@Header("Authorization") String fbkey, @Body HashMap<String,Object> jsonbody);

    @FormUrlEncoded
    @POST("api/getMechanicInfo")
    Call<Mechanic> getMechanicInfo(@Header("Authorization") String authorization, @Field("mechanic_id") int mechanic_id);

    @FormUrlEncoded
    @POST("api/getNotifInfo")
    Call<JsonObject> getNotifInfo(@Header("Authorization") String authorization, @Field("notif_id") int notif_id);

    @FormUrlEncoded
    @POST("api/getAllNotif")
    Call<List<Notifications>> getAllNotif(@Header("Authorization") String authorization, @Field("id") int id );
    @FormUrlEncoded
    @POST("api/getAllHisto")
    Call<List<Notifications>> getAllHisto(@Header("Authorization") String authorization, @Field("id") int id, @Field("isMechanic") int isMechanic );


    @FormUrlEncoded
    @POST("api/notifRequestFromCancel")
    Call<Void> notifRequestFromCancel(@Header("Authorization") String authorization, @Field("driver_id") int driver_id, @Field("mechanic_id") int mechanic_id, @Field("date") String date, @Field("request_emergency_id") int request_emergency_id);

    @FormUrlEncoded
    @POST("api/notifRequestFromAccept")
    Call<Void> notifRequestFromAccept(@Header("Authorization") String authorization, @Field("driver_id") int driver_id, @Field("mechanic_id") int mechanic_id, @Field("date") String date, @Field("request_emergency_id") int request_emergency_id, @Field("delay") String delay);


}