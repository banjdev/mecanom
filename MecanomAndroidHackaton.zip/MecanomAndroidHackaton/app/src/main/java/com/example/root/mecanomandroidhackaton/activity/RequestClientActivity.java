package com.example.root.mecanomandroidhackaton.activity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.root.mecanomandroidhackaton.ControlModel.notifAcecptRequest;
import com.example.root.mecanomandroidhackaton.ControlModel.notifCancelRequest;
import com.example.root.mecanomandroidhackaton.model.Locations;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;
import com.example.root.mecanomandroidhackaton.R;

import static com.example.root.mecanomandroidhackaton.util.Utils.getDouble;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_LOCATION;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.QtifyValue;


public class RequestClientActivity extends AppCompatActivity implements OnMapReadyCallback,SwipeRefreshLayout.OnRefreshListener {

    private Button sendInfo;
    private Spinner spinnerDelay;
     private EditText amountEditText;

    private TextView markLabel,modelLabel,yearLabel,addressLabel,troubleLabel,phone,email;
    private Button declineButton,acceptButton;
    private Users users = null,  userDriver = null;
    private SharedPreferences mPrefs,mPrefsL;
    private double longitude = 0.0;
    private double latittude= 0.0;
    private HashMap<Marker, Integer> mHashMap;
    private ArrayList<Users> DriverList;
    private int notif_id;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private String userDriver_json;
    private TableRow row_phone;

    private String selectedItemQtiFy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_client);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        bindViews();

        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.activity_main_swipe_refresh_layout);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        mPrefs = getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);
        mPrefsL = getSharedPreferences(PREFS_LOCATION, MODE_PRIVATE);
        longitude = getDouble(mPrefsL, "longitude", 0.0);
        latittude = getDouble(mPrefsL, "latittude", 0.0);

        Gson gson = new Gson();
        String json = mPrefs.getString("user_main_info", "");
        users = gson.fromJson(json, Users.class);


        userDriver_json = getIntent().getStringExtra("userDriver");
        userDriver = gson.fromJson(userDriver_json, Users.class);



        if(userDriver!=null) {
            initValues(userDriver);
        }

        setListener();
    }

    private void setListener() {

        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Utils.isIntenetAvailavle(RequestClientActivity.this))
                    new notifCancelRequest(users,RequestClientActivity.this, userDriver).sendIt();
                else
                    Utils.ToastMsg(RequestClientActivity.this,"verifiez votre connection,reessayez");


            }
        });

        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LayoutInflater inflater1 = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
                View layout = inflater1.inflate(R.layout.delay, null);
                if (layout.getParent() != null)
                    ((ViewGroup) layout.getParent()).removeView(layout);


                final AlertDialog alertDialog = new AlertDialog.Builder(RequestClientActivity.this).create();
                alertDialog.setView(layout);

                final ImageButton Btn_Close = layout.findViewById(R.id.btn_close);
                sendInfo = layout.findViewById(R.id.btn_send);
                amountEditText = (EditText) layout.findViewById(R.id.amount);


                spinnerDelay = layout.findViewById(R.id.qtify);


                ArrayAdapter<String> ArrayAdapterDelay = new ArrayAdapter<String>
                        (RequestClientActivity.this, android.R.layout.simple_spinner_item, QtifyValue());

                ArrayAdapterDelay.setDropDownViewResource(R.layout
                        .custom_spinner_dropdown_item);
                spinnerDelay.setAdapter(ArrayAdapterDelay);


                spinnerDelay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                    {
                        selectedItemQtiFy = parent.getItemAtPosition(position).toString();

                    }
                    public void onNothingSelected(AdapterView<?> parent)
                    {

                    }
                });


                alertDialog.show();

                Btn_Close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });

                sendInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                                if(amountEditText.getText() != null){
                                    String final_amount = amountEditText.getText()+" "+selectedItemQtiFy;
                                    if (Utils.isIntenetAvailavle(RequestClientActivity.this))
                                        new notifAcecptRequest(users,RequestClientActivity.this,  userDriver,final_amount).sendIt();
                                    else
                                        Utils.ToastMsg(RequestClientActivity.this,"verifiez votre connection,reessayez");

                                }
                        alertDialog.dismiss();

                    }
                });



             }
        });
    }

    public void onRefresh() {
        refreshContent();
    }

    private void refreshContent(){
//        userDriver = new getMechanicInfo(RequestClientActivity.this,userDriver, notif_id).getIt();
//        if(userDriver == null){
//            final Snackbar snackbarP = Snackbar.make(findViewById(android.R.id.content), getResources().getString(R.string.server_error), Snackbar.LENGTH_INDEFINITE);
//            snackbarP.setAction("retry", new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    snackbarP.dismiss();
//                    userDriver = new getNotifInfo(users,RequestClientActivity.this, notif_id).getIt();
//
//                    initValues(userDriver);
//                }
//            }).show();
//        }
        mSwipeRefreshLayout.setRefreshing(false);
    }


    private void bindViews(){
        row_phone = findViewById(R.id.row_phone);
        markLabel = findViewById(R.id.mark);
        modelLabel = findViewById(R.id.model);
        yearLabel = findViewById(R.id.year_picker);
        addressLabel = findViewById(R.id.adress);
        troubleLabel = findViewById(R.id.trouble);
        phone = findViewById(R.id.phone);
        email = findViewById(R.id.email);

        declineButton = findViewById(R.id.decline);
        acceptButton = findViewById(R.id.accept);
    }

    private void initValues(Users userDriver) {
        if (userDriver != null) {


            if(userDriver.getPhone() == null)
                row_phone.setVisibility(View.GONE);
            else
                phone.setText(userDriver.getPhone());
            markLabel.setText(userDriver.getNotifications().getDetailVehicule().getMark());
            modelLabel.setText(userDriver.getNotifications().getDetailVehicule().getModel());
            yearLabel.setText(String.valueOf(userDriver.getNotifications().getDetailVehicule().getYear()) );
            troubleLabel.setText(userDriver.getNotifications().getDetailVehicule().getTrouble());
            try {
                addressLabel.setText(userDriver.getNotifications().getLocations().getAdress());
            }
            catch(Exception e){

            }

            email.setText(userDriver.getEmail());
            phone.setText(userDriver.getPhone());

            if (userDriver.getNotifications().getStatus() == 1){
                declineButton.setEnabled(false);
                acceptButton.setEnabled(false);
                Utils.ToastMsg(RequestClientActivity.this,"requete deja envoyee");
//                declineButton.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Utils.ToastMsg(RequestClientActivity.this,"requete deja envoyee");
//                    }
//                });
//                acceptButton.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Utils.ToastMsg(RequestClientActivity.this,"requete deja envoyee");
//                    }
//                });
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        if(longitude != 0.0 && latittude != 0.0) {

            final LatLng myPosition = new LatLng(latittude, longitude);

            mHashMap = PlaceMarKerOnMap(googleMap, myPosition);

            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myPosition,1));
//            googleMap.setMaxZoomPreference(6.0f);


            googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener()
            {
                @Override
                public boolean onMarkerClick(Marker arg0) {
                    if(arg0 != null && arg0.getPosition().equals(myPosition)) { // if marker  source is clicked
                        Toast.makeText(RequestClientActivity.this, "my position", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(RequestClientActivity.this, "position du client", Toast.LENGTH_SHORT).show();
                    }
                    return true;

                }

            });
        }

    }

    private HashMap<Marker, Integer> PlaceMarKerOnMap(GoogleMap googleMap, LatLng myPosition) {


        Locations locations = new Locations(latittude,longitude);

        //driver
        Users driver = new Users( );


        mHashMap = new HashMap<Marker, Integer>();
        DriverList = new ArrayList<Users>();

        DriverList.add(driver);

        googleMap.addMarker(new MarkerOptions().position(new LatLng(locations.getLatitude()
                ,locations.getLongitude()))
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                .title("me"));

        for (int i = 0; i < DriverList.size(); i++) {
            Marker marker = googleMap.addMarker(new MarkerOptions().position(new LatLng(DriverList.get(i).getLocations().getLatitude(),  DriverList.get(i).getLocations().getLongitude()))
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));

            mHashMap.put(marker, i);
        }

        return mHashMap;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case android.R.id.home:
            {
                onBackPressed();
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
