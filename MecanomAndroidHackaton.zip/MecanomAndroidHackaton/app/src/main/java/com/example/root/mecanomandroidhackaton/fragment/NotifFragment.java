package com.example.root.mecanomandroidhackaton.fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.root.mecanomandroidhackaton.ControlModel.getAllNotif;
import com.example.root.mecanomandroidhackaton.R;
import com.example.root.mecanomandroidhackaton.adapter.NotificationAdapter;
import com.example.root.mecanomandroidhackaton.model.Notifications;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;

public class NotifFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private SharedPreferences mPrefs;
    private Users users = null;
    private boolean haveNotif = false;
    private RecyclerView recyclerView;
    private NotificationAdapter adapter;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    List<Notifications> notifications = new ArrayList<Notifications>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Notifications");
        return inflater.inflate(R.layout.activity_notif, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        recyclerView = getView().findViewById(R.id.recycler);
        mSwipeRefreshLayout = (SwipeRefreshLayout) getView().findViewById(R.id.activity_main_swipe_refresh_layout);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mPrefs = getContext().getSharedPreferences(PREFS_USER_Main, MODE_PRIVATE);

        Gson gson = new Gson();
        String json = mPrefs.getString("user_main_info", "");
        users = gson.fromJson(json, Users.class);

        adapter = new NotificationAdapter(notifications, users.getIsMechanic(), getContext(), users);
        recyclerView.setAdapter(adapter);


        haveNotif = new getAllNotif(users, getContext(), adapter).getAll();
    }


    @Override
    public void onRefresh() {
        refreshContent();
    }

    private void refreshContent() {
        if (haveNotif == false) {
//            final Snackbar snackbarP = Snackbar.make(findViewById(android.R.id.content), getResources().getString(R.string.server_error), Snackbar.LENGTH_INDEFINITE);
//            snackbarP.setAction("reesayez", new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    snackbarP.dismiss();
//                    if (Utils.isIntenetAvailavle(NotifActivity.this))
//                        new getAllNotif(users,NotifActivity.this,adapter).getAll();
//                    else
//                        Utils.ToastMsg(NotifActivity.this,"verifiez votre connection,reessayez");
//
//                }
//            }).show();
            if (Utils.isIntenetAvailavle(getContext()))
                new getAllNotif(users, getContext(), adapter).getAll();
            else
                Utils.ToastMsg(getContext(), "verifiez votre connection,reessayez");
        }
        mSwipeRefreshLayout.setRefreshing(false);
    }

}



