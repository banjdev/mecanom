
package com.example.root.mecanomandroidhackaton.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Mechanic implements Parcelable
{

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("user_id")
    @Expose
    private Integer userId;
    @SerializedName("services")
    @Expose
    private String services;
    @SerializedName("specialisation")
    @Expose
    private String specialisation;
    @SerializedName("availability")
    @Expose
    private String availability;
    @SerializedName("haveScanner")
    @Expose
    private Integer haveScanner;
    @SerializedName("haveTug")
    @Expose
    private Integer haveTug;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("created_at")
    @Expose
    private String createdAt;
    @SerializedName("updated_at")
    @Expose
    private String updatedAt;
    @SerializedName("garage")
    @Expose
    private Garage garage;
    @SerializedName("user")
    @Expose
    private Users user;
    @SerializedName("location")
    @Expose
    private Locations locations;
    public final static Parcelable.Creator<Mechanic> CREATOR = new Creator<Mechanic>() {


        @SuppressWarnings({
                "unchecked"
        })
        public Mechanic createFromParcel(Parcel in) {
            return new Mechanic(in);
        }

        public Mechanic[] newArray(int size) {
            return (new Mechanic[size]);
        }

    }
            ;

    protected Mechanic(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.userId = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.services = ((String) in.readValue((String.class.getClassLoader())));
        this.specialisation = ((String) in.readValue((String.class.getClassLoader())));
        this.availability = ((String) in.readValue((Integer.class.getClassLoader())));
        this.haveScanner = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.haveTug = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.rating = ((Double) in.readValue((Double.class.getClassLoader())));
        this.createdAt = ((String) in.readValue((String.class.getClassLoader())));
        this.updatedAt = ((String) in.readValue((String.class.getClassLoader())));
        this.locations = ((Locations) in.readValue((Locations.class.getClassLoader())));

        this.user = ((Users) in.readValue((Users.class.getClassLoader())));
        this.garage = ((Garage) in.readValue((Garage.class.getClassLoader())));
    }

    /**
     * No args constructor for use in serialization
     *
     */
    public Mechanic() {
    }

    /**
     *
     * @param updatedAt
     * @param id
     * @param specialisation
     * @param services
     * @param createdAt
     * @param userId
     * @param haveTug
     * @param rating
     * @param haveScanner
     * @param user
     * @param availability
     */
    public Mechanic(Integer id, Integer userId, String services, String specialisation, String availability, Integer haveScanner, Integer haveTug, Double rating, String createdAt, String updatedAt, Users user) {
        super();
        this.id = id;
        this.userId = userId;
        this.services = services;
        this.specialisation = specialisation;
        this.availability = availability;
        this.haveScanner = haveScanner;
        this.haveTug = haveTug;
        this.rating = rating;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.user = user;

    }

    public Locations getLocations() {
        return locations;
    }

    public void setLocations(Locations locations) {
        this.locations = locations;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getServices() {
        return services;
    }

    public void setServices(String services) {
        this.services = services;
    }

    public String getSpecialisation() {
        return specialisation;
    }

    public void setSpecialisation(String specialisation) {
        this.specialisation = specialisation;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    public Integer getHaveScanner() {
        return haveScanner;
    }

    public void setHaveScanner(Integer haveScanner) {
        this.haveScanner = haveScanner;
    }

    public Integer getHaveTug() {
        return haveTug;
    }

    public void setHaveTug(Integer haveTug) {
        this.haveTug = haveTug;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Users getUser() {
        return user;
    }


    public Garage getGarage() {
        return garage;
    }

    public void setGarage(Garage garage) {
        this.garage = garage;
    }



    public void setUser(Users user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "Mechanic{" +
                "id='" + id + '\'' +
                ", location='" + locations + '\'' +

                ", user_id='" + userId + '\'' +
                ", haveScanner='" + haveScanner + '\'' +
                ", specialisation='" + specialisation + '\'' +
                ", availability='" + availability + '\'' +
                ", rating='" + rating + '\'' +
                ", haveTug='" + haveTug + '\'' +
                ", user='" + user + '\'' +
                ", garage='" + garage + '\'' +
                ", created_at='" + createdAt + '\'' +
                ", updated_at='" + updatedAt + '\'' +
                '}';
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(userId);
        dest.writeValue(services);
        dest.writeValue(specialisation);
        dest.writeValue(availability);
        dest.writeValue(haveScanner);
        dest.writeValue(haveTug);
        dest.writeValue(rating);
        dest.writeValue(createdAt);
        dest.writeValue(updatedAt);
        dest.writeValue(user);
        dest.writeValue(garage);
        dest.writeValue(locations);

    }

    public int describeContents() {
        return 0;
    }

}
