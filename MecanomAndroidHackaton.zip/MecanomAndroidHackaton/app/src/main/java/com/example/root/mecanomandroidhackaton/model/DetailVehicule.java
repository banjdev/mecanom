package com.example.root.mecanomandroidhackaton.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class DetailVehicule implements Parcelable
{

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("mark")
    @Expose
    private String mark;
    @SerializedName("model")
    @Expose
    private String model;
    @SerializedName("transmission")
    @Expose
    private String transmission;
    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("year")
    @Expose
    private int year;
    @SerializedName("trouble")
    @Expose
    private String trouble;
    public final static Parcelable.Creator<DetailVehicule> CREATOR = new Creator<DetailVehicule>() {


        @SuppressWarnings({
                "unchecked"
        })
        public DetailVehicule createFromParcel(Parcel in) {
            return new DetailVehicule(in);
        }

        public DetailVehicule[] newArray(int size) {
            return (new DetailVehicule[size]);
        }

    }
            ;

    protected DetailVehicule(Parcel in) {
        this.id = ((String) in.readValue((String.class.getClassLoader())));
        this.mark = ((String) in.readValue((String.class.getClassLoader())));
        this.model = ((String) in.readValue((String.class.getClassLoader())));
        this.transmission = ((String) in.readValue((String.class.getClassLoader())));
        this.date = ((String) in.readValue((String.class.getClassLoader())));
        this.year = ((int) in.readValue((int.class.getClassLoader())));
        this.trouble = ((String) in.readValue((String.class.getClassLoader())));
    }

    public DetailVehicule() {
    }

    public DetailVehicule(String mark, String model, String date, String transmission) {
        this.mark = mark;
        this.model = model;
        this.date = date;
        this.transmission = transmission;
    }

    public DetailVehicule(String mark, String model, int year , String transmission, String trouble) {
        this.mark = mark;
        this.model = model;
        this.year = year;
        this.transmission = transmission;
        this.trouble = trouble;
    }

    public DetailVehicule(String mark, String model, int year , String transmission ) {
        this.mark = mark;
        this.model = model;
        this.year = year;
        this.transmission = transmission;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTrouble() {
        return trouble;
    }

    public void setTrouble(String trouble) {
        this.trouble = trouble;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "DetailVehicule{" +
                "id='" + id + '\'' +
                ", mark='" + mark + '\'' +
                ", model='" + model + '\'' +
                ", transmission='" + transmission + '\'' +
                ", date='" + date + '\'' +
                ", year='" + year + '\'' +
                ", trouble='" + trouble + '\'' +
                '}';
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(mark);
        dest.writeValue(model);
        dest.writeValue(transmission);
        dest.writeValue(date);
        dest.writeValue(year);
        dest.writeValue(trouble);
    }

    public int describeContents() {
        return 0;
    }
}
