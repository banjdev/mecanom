package com.example.root.mecanomandroidhackaton.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.root.mecanomandroidhackaton.ControlModel.getNotifInfo;
import com.example.root.mecanomandroidhackaton.model.Notifications;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.example.root.mecanomandroidhackaton.R;



public class HistoryAdapter extends  RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<Notifications> items= new ArrayList<Notifications>();
    private Notifications item;
    private Context context;
    private int ismechanic;
    private Users users;

    public HistoryAdapter(List<Notifications> items, int ismechanic, Context context, Users users) {
        this.items = items;
        this.ismechanic = ismechanic;
        this.context = context;
        this.users = users;
    }


    public void setItems(List<Notifications> items) {
            this.items = items;
            Collections.reverse(this.items);
            this.notifyDataSetChanged();
            }

    @Override
    public HistoryAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lay_notif, parent, false);
            return new HistoryAdapter.ViewHolder(view);
            }

    @Override
    public void onBindViewHolder(final HistoryAdapter.ViewHolder holder, int position) {
            item = items.get(position);

            holder.titleText.setText("le "+item.getDate());
            if(users.getIsMechanic() == 0) {
                if (item.getPrincipal_id() != users.getId())
                    holder.messageText.setText("vous aviez contacter un mechanicien");


            }
            else
            {
                if (item.getPrincipal_id() == users.getId())
                    holder.messageText.setText("vous avez ete contacter par un client");

            }

            holder.dateText.setVisibility(View.GONE);
            holder.Btn_Del.setVisibility(View.GONE);

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if(users.getIsMechanic() == 0) {
                        if (item.getPrincipal_id() != users.getId()) {
                            if (Utils.isIntenetAvailavle(context))
                                new getNotifInfo(users, context, items.get(holder.getAdapterPosition()).getId(), 1).getIt();
                            else
                                Utils.ToastMsg(context, "verifiez votre connection,reessayez");
                        }
                    }
                    else {
                        if (item.getPrincipal_id() == users.getId()) {
                            if (Utils.isIntenetAvailavle(context))
                                new getNotifInfo(users, context, items.get(holder.getAdapterPosition()).getId(), 1).getIt();
                            else
                                Utils.ToastMsg(context, "verifiez votre connection,reessayez");
                        }
                    }
                }
            });

            }

    @Override
    public int getItemCount() {
            return items.size();
            }


    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView messageText, titleText,dateText;
        private ImageButton Btn_Del;
        public ViewHolder(View itemView) {
            super(itemView);
            messageText = (TextView)itemView.findViewById(R.id.msg);
            titleText = (TextView)itemView.findViewById(R.id.title);
            dateText = (TextView)itemView.findViewById(R.id.date);
            Btn_Del = (ImageButton)itemView.findViewById(R.id.delete);


        }
    }
}

