package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.activity.MainActivity;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;

import static com.example.root.mecanomandroidhackaton.util.Utils.getRealTime;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;


/**
 * Created by root on 08/04/18.
 */

public class notifAcecptRequest {

    private String token,fbkey,trouble,delay;
    private Users userMechanic = null;
    private Context context;
    private ProgressDialog progressDialog;
    private HashMap<String,Object> data;
    private Users userDriver;


    public notifAcecptRequest(Users userMechanic, Context context , Users userDriver, String delay) {
        this.userMechanic = userMechanic;
        this.context = context;
        this.userDriver = userDriver;
        this.delay = delay;
    }

    public void sendIt(){

        progressDialog = new ProgressDialog( context);
        progressDialog.setTitle("un instant ...");
        progressDialog.show();

        ApiService service = getApiService();
        token = "Bearer " + userMechanic.getToken();
        Call<Void> call = service.notifRequestFromAccept(token, userDriver.getId(),userMechanic.getId(),getRealTime(),userDriver.getNotifications().getReqest_emergency_id(),delay);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, retrofit2.Response<Void> response) {
                Log.i("Halla",""+response);
                if (response.code() == 200) {
                    Utils.ToastMsg(context,"Demande d'assistance accepter");
                    Intent i = new Intent(context, MainActivity.class);
                    i.putExtra("history", "history");
                    context.startActivity(i);
                }
                else if(response.code() == 905) {
                    Intent i = new Intent(context, MainActivity.class);
                    i.putExtra("history", "history");
                    context.startActivity(i);
                }
                else {
                    Utils.ToastMsg(context,"erreur de connexion1,reesayez");
                    progressDialog.dismiss();
                }

            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Utils.ToastMsg(context,"erreur de connexion2,reesayez");

                Log.i("Hello", ""+t);
                progressDialog.dismiss();
            }
        });
    }


}
