package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import com.example.root.mecanomandroidhackaton.activity.MainActivity;
import com.example.root.mecanomandroidhackaton.model.DetailVehicule;
import com.example.root.mecanomandroidhackaton.model.Locations;
import com.example.root.mecanomandroidhackaton.model.Mechanic;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;

import static android.content.Context.MODE_PRIVATE;
import static com.example.root.mecanomandroidhackaton.util.Utils.getDouble;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_LOCATION;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;



public class saveNotifClientMainRequest {

    private String token,fbkey,trouble;
    private Users userDriver = null;
    private Mechanic userMechanic;
    private Context context;
    private ProgressDialog progressDialog;
    private HashMap<String,Object> data;
    private DetailVehicule detailVehicule = null;
    private Locations locations = null;
    private SharedPreferences mPrefsL;



    public saveNotifClientMainRequest(Users userDriver, Mechanic userMechanic, Context context, DetailVehicule detailVehicule ) {
        this.userDriver = userDriver;
        this.userMechanic = userMechanic;
        this.context = context;
        this.detailVehicule = detailVehicule;
//        this.locations = locations;
    }

    public void sendIt(){

        progressDialog = new ProgressDialog( context);
        progressDialog.setTitle("un instant ...");
        progressDialog.show();

        mPrefsL = context.getSharedPreferences(PREFS_LOCATION, MODE_PRIVATE);

        locations = new Locations(
                Utils.getAddress(
                        getDouble(mPrefsL, "latittude", 0.0),
                        getDouble(mPrefsL, "longitude", 0.0),
                        context)
        );


        ApiService service = getApiService();
        token = "Bearer " + userDriver.getToken();
        data = new HashMap<>();
        data.put("userDriver",userDriver);
        data.put("mechanic_id",userMechanic.getUser().getId());
        data.put("detailVehicule",detailVehicule);
        data.put("locations",locations);
System.out.println("debug_notif=>"+data);
        Call<Void> call = service.sendInfoToMechanician(token, data );

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, retrofit2.Response<Void> response) {
                Log.i("Halla",""+response);
                if (response.code() == 200) {
                    Utils.ToastMsg(context,"Demande d'assistance envoyée");
                     Intent i = new Intent(context, MainActivity.class);
                    i.putExtra("history", "history");
                    context.startActivity(i);
                }
                else if(response.code() == 905) {
                    Intent i = new Intent(context, MainActivity.class);
                    i.putExtra("history", "history");
                    context.startActivity(i);
                }
                else {
                    Utils.ToastMsg(context,"erreur de connexion1,reesayez");
                    progressDialog.dismiss();

                }

            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.i("Hello", ""+t);
                progressDialog.dismiss();
            }
        });

                        progressDialog.dismiss();


        Toast.makeText(context,"Demande d'assistance en cours", Toast.LENGTH_LONG).show();
    }

 }
