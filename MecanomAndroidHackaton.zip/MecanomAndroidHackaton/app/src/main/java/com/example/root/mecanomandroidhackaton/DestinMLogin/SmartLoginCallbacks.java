package com.example.root.mecanomandroidhackaton.DestinMLogin;


import com.example.root.mecanomandroidhackaton.DestinMLogin.util.SmartLoginException;
import com.example.root.mecanomandroidhackaton.model.Users;

/**
 * Copyright (c) 2017 Codelight Studios
 * Created by kalyandechiraju on 22/04/17.
 */

public interface SmartLoginCallbacks {

    void onLoginSuccess(Users user);

    void onLoginFailure(SmartLoginException e);

    Users doCustomLogin();

    Users doCustomSignup();
}
