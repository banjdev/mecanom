package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.activity.FicheActivity;
import com.example.root.mecanomandroidhackaton.activity.RequestClientActivity;
import com.example.root.mecanomandroidhackaton.model.DetailVehicule;
import com.example.root.mecanomandroidhackaton.model.Locations;
import com.example.root.mecanomandroidhackaton.model.Notifications;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;


public class getNotifInfo {

    private Users userDriver = null;
    private String token;
    private Users users =null;
    private Context context;
    private int notif_id;
    private int fromConnect=0;
    private String jsonData;

    public getNotifInfo(Users users, Context context, int notif_id) {
        this.users = users;
        this.context = context;
        this.notif_id = notif_id;
    }
    public getNotifInfo(Users users, Context context, int notif_id, int fromConnect) {
        this.users = users;
        this.context = context;
        this.notif_id = notif_id;
        this.fromConnect = fromConnect;
    }
    public Users getIt( ) {

        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("un instant ...");
        progressDialog.show();
        ApiService service = getApiService();
        token = "Bearer " + users.getToken();
        Call<JsonObject> call = service.getNotifInfo(token, notif_id);



        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                Log.i("Halla", "" + response.body());
                if (response.code() == 200) {
                    jsonData = response.body().toString();
                    Gson gson = new Gson();
                    DetailVehicule detailVehicule;
                    Locations locations;
                    Notifications notifications;

                    try {
                        JSONObject jsonAllData =  new JSONObject(jsonData);
                        notifications = new Notifications();
                        detailVehicule = new DetailVehicule(
                                jsonAllData.getJSONObject("notifications")
                                .getJSONObject("detailVehicule")
                                .getString("mark")
                                ,jsonAllData.getJSONObject("notifications")
                                .getJSONObject("detailVehicule")
                                .getString("model")
                                ,jsonAllData.getJSONObject("notifications")
                                        .getJSONObject("detailVehicule")
                                        .getInt("year" )
                                ,jsonAllData.getJSONObject("notifications")
                                        .getJSONObject("detailVehicule")
                                        .getString("transmission")
                                ,jsonAllData.getJSONObject("notifications")
                                .getString("trouble")
                        );
                        System.out.println("n"+jsonAllData.getJSONObject("notifications") );
                        notifications.setId(jsonAllData.getJSONObject("notifications")
                                .getInt("id" ));
                        notifications.setDetailVehicule(detailVehicule);
                        notifications.setStatus(
                                jsonAllData.getJSONObject("notifications")
                                        .getInt("status" )
                        );
                        notifications.setReqest_emergency_id(
                                jsonAllData.getJSONObject("notifications")
                                        .getInt("request_emergency_id" )
                        );
                        notifications.setDriver_name(
                                jsonAllData.getJSONObject("notifications")
                                        .getString("driver_name" )
                        );
                        notifications.setMechanic_name(
                                jsonAllData.getJSONObject("notifications")
                                        .getString("mechanic_name" )
                        );

                        notifications.setGarage_name(
                                jsonAllData.getJSONObject("notifications")
                                        .getString("garage_name" )
                        );

                        notifications.setGarage_address(
                                jsonAllData.getJSONObject("notifications")
                                        .getString("garage_address" )
                        );

                        locations = new Locations(
                                jsonAllData.getJSONObject("notifications")
                                .getJSONObject("locations")
                                .getString("adress")
                        );

                        notifications.setLocations(locations);

                        userDriver = new Users();
                        userDriver.setEmail(jsonAllData.
                                getString("email"));

                        userDriver.setId(
                                jsonAllData.
                                        getInt("id")
                        );

                        userDriver.setNotifications(notifications);



                    } catch (JSONException e) {
                        e.printStackTrace();
                    }



                    String json = gson.toJson(userDriver);
                    System.out.println("na"+json );
                    if(fromConnect == 0) {
                        progressDialog.dismiss();
                        context.startActivity(new Intent(context, RequestClientActivity.class).putExtra("userDriver", json));
                    }
                    else{
                        progressDialog.dismiss();
                        context.startActivity(new Intent(context, FicheActivity.class).putExtra("userDriver", json));

                    }
                } else {
                    progressDialog.dismiss();
                    Utils.ToastMsg(context,"erreur de connexion1,reesayez");
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.i("Hello", "" + t);
                progressDialog.dismiss();
                Utils.ToastMsg(context,"erreur de connexion2,reesayez");
            }
        });

        return userDriver;
    }
}
