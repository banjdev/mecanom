package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.model.Locations;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;

import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;

public class changeMechanicLocation {


    private String token ;
    private Users userMechanic = null;
    private Locations locations = null;
    private Context context;
    private ProgressDialog progressDialog;
    private HashMap<String,Object> data;

    public changeMechanicLocation(Users userMechanic, Locations locations, Context context) {
        this.userMechanic = userMechanic;
        this.locations = locations;
        this.context = context;
    }


    public void sendIt(){

        progressDialog = new ProgressDialog( context);
        progressDialog.setTitle("un instant ...");
        progressDialog.show();

        locations.setAdress( Utils.getAddress(
                locations.getLatitude(),
                locations.getLongitude(),
                context));


        ApiService service = getApiService();
        token = "Bearer " + userMechanic.getToken();
        data = new HashMap<>();
        data.put("user_id",userMechanic.getId());
        data.put("location",locations);
        System.out.println("debug_loc_tomecha=>"+data);
        Call<Void> call = service.changeMechanicLocation(token, data );

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, retrofit2.Response<Void> response) {
                Log.i("Halla",""+response);
                if (response.code() == 200) {
                    Utils.ToastMsg(context,"Changement effectué avec succes");

                }
                else {
                    Utils.ToastMsg(context,"erreur de connexion1,reesayez");
                    progressDialog.dismiss();

                }

            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.i("Hello", ""+t);
                progressDialog.dismiss();
            }
        });

        progressDialog.dismiss();


    }




}
