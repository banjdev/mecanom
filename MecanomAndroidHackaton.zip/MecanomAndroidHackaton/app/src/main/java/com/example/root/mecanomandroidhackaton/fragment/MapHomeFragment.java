package com.example.root.mecanomandroidhackaton.fragment;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.root.mecanomandroidhackaton.ControlModel.getMechanicInfo;
import com.example.root.mecanomandroidhackaton.R;
import com.example.root.mecanomandroidhackaton.model.Locations;
import com.example.root.mecanomandroidhackaton.model.Mechanic;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static com.example.root.mecanomandroidhackaton.util.Utils.getDouble;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_HIDE_DIALOG;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_INFO;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_LOCATION;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;



public class MapHomeFragment extends Fragment implements  OnMapReadyCallback {

    private SupportMapFragment mapFragment;
    private List<Mechanic> mechanicList = new ArrayList<Mechanic>();
    private double longitude = 0.0;
    private double latittude= 0.0;
    private HashMap<Marker, Integer> mHashMap = new HashMap<>();
    private Users users = null;
    private SharedPreferences mPrefs,mPrefsL,mPrefsHD,mPrefsI;
     private LatLngBounds bounds;
    private RelativeLayout relativeLayoutMain;
    private ImageView view_mechanic;
    private String mechanicList_json;
    private CoordinatorLayout myCoordinator;
    private boolean hide_dialog = false;


    public MapHomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Demande de dépannage");

        myCoordinator = (CoordinatorLayout) getActivity().findViewById(R.id.coordinator);

        mPrefs = getContext().getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);

        // Get the SupportMapFragment and request notification
// when the map is ready to be used.
        mapFragment = (SupportMapFragment) this.getChildFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        if(users ==null){
            Gson gson = new Gson();
            String json = mPrefs.getString("user_main_info", "");
            users = gson.fromJson(json, Users.class);

        }
        if (users != null){
            if (users.getIsMechanic() == 0) {
                mPrefsL = getContext().getSharedPreferences(PREFS_LOCATION, MODE_PRIVATE);
                longitude = getDouble(mPrefsL, "longitude", 0.0);
                latittude = getDouble(mPrefsL, "latittude", 0.0);
                mPrefsI =  getContext().getSharedPreferences(PREFS_INFO,MODE_PRIVATE);



                System.out.println("asalaln"+mechanicList_json);

                mPrefsHD = getContext().getSharedPreferences(PREFS_HIDE_DIALOG,MODE_PRIVATE);
            }
            if (users.getIsMechanic() == 1){
                relativeLayoutMain = getView().findViewById(R.id.main_view);
                mapFragment.getView().setVisibility(View.GONE);

                relativeLayoutMain.setBackgroundColor(getResources().getColor(R.color.toolbar_principal));
                mapFragment.getView().setVisibility(View.GONE);
                view_mechanic = getView().findViewById(R.id.view_mechanic);
                view_mechanic.setVisibility(View.VISIBLE);

                view_mechanic.getLayoutParams().height = Utils.getPercent(50,Utils.ScreenHeight(getContext()));

            }
        }




    }

    private void msg_indication(String msg) {
        if(!hide_dialog) {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
//                    alertDialog.setTitle(R.string.msgChangeUsername);
            alertDialog.setMessage(msg);


            alertDialog.setPositiveButton("ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                        }
                    });
            alertDialog.setNegativeButton("ne plus afficher",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            SharedPreferences.Editor prefsEditor = mPrefsHD.edit();
                            prefsEditor.putBoolean("hide_dialog_msg", true);
                            prefsEditor.commit();
                            dialog.cancel();

                        }
                    });


            alertDialog.show();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_map_home, container, false);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        if(longitude != 0.0 && latittude != 0.0) {

            getView().findViewById(R.id.loadingPanel).setVisibility(View.GONE);


            final LatLng myPosition = new LatLng(latittude, longitude);


            mHashMap = PlaceMarKerOnMap(googleMap, myPosition);

            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myPosition,15));


            googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener()
            {
                @Override
                public boolean onMarkerClick(Marker arg0) {
                    if(arg0 != null && arg0.getPosition().equals(myPosition)) { // if marker  source is clicked
                        Toast.makeText(getContext(), "Ma position actuelle", Toast.LENGTH_SHORT).show();
                    }
                    else{

                        if(mechanicList !=null) {

                            int id = mHashMap.get(arg0);
//                                            Mechanic user = mHashMap.get(id);
                            getView().findViewById(R.id.loadingPanel).setVisibility(View.VISIBLE);
                                 new getMechanicInfo(getContext(),users,id).getIt();


                        }
                    }
                    return true;

                }

            });
        }

    }

    private HashMap<Marker, Integer> PlaceMarKerOnMap(GoogleMap googleMap, LatLng myPosition) {

        SharedPreferences mPrefsUserAll =   PreferenceManager.getDefaultSharedPreferences(getContext());
        Type listType = new TypeToken<List<Mechanic>>() {}.getType();
        Gson gson = new Gson();
        String json = mPrefsUserAll.getString("mechaniclist", "");


        mechanicList = gson.fromJson(json, listType);

        Locations locations = new Locations(latittude,longitude);




//        ImageView image = (ImageView) findViewById(R.id.image_maker);
//
//        LinearLayout tv = (LinearLayout) this.getLayoutInflater().inflate(R.layout.maker, null, false);
//        tv.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
//                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
//        tv.layout(0, 0, tv.getMeasuredWidth(), tv.getMeasuredHeight());
//
//        tv.setDrawingCacheEnabled(true);
//        tv.buildDrawingCache();
//        Bitmap bm = tv.getDrawingCache();
//        MarkerStyle(MechanicList.get(i).getPseudo(),R.drawable.ic_place_red_24dp)
        LatLngBounds.Builder builder  = new LatLngBounds.Builder();

        Marker mymaker = googleMap.addMarker(new MarkerOptions().position(myPosition)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                .title("me"));



        builder.include(mymaker.getPosition());
        if(mechanicList != null) {

            if (mechanicList.size() != 0) {


                for (int i = 0; i < mechanicList.size(); i++) {

                    if(mechanicList.get(i).getLocations() != null) {

                        Marker marker = googleMap.addMarker(new MarkerOptions().position(new LatLng(mechanicList.get(i).getLocations().getLatitude(), mechanicList.get(i).getLocations().getLongitude()))
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));

                        mHashMap.put(marker, mechanicList.get(i).getId());


                        builder.include(marker.getPosition());
                    }

                }
                bounds = builder.build();
            }

        }

        return mHashMap;
    }


}
