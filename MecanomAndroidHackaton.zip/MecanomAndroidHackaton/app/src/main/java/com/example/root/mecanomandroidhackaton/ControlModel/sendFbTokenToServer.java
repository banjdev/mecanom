package com.example.root.mecanomandroidhackaton.ControlModel;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.model.Users;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;

import static android.content.Context.MODE_PRIVATE;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.saveUserMainInfo;


public class sendFbTokenToServer {


    private SharedPreferences mPrefs ;
    private Users users = null;
    private Context context ;
    private String token;

    public sendFbTokenToServer(Context context) {
        this.context = context;
    }

    public void sendRegistrationToServer(String refreshedToken) {
        mPrefs = context.getSharedPreferences(PREFS_USER_Main, MODE_PRIVATE);
        Gson gson = new Gson();
        String json = mPrefs.getString("user_main_info", "");
        users = gson.fromJson(json, Users.class);

        if (users != null) {

            ApiService service = getApiService();
            token = "Bearer " + users.getToken();
            Call<Void> call = service.refreshFbToken(token, users.getId(), refreshedToken);

            call.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, retrofit2.Response<Void> response) {
                    Log.i("Halla", "" + response);
                    if (response.code() == 200) {
                        users.setLocation_id(1);
                        saveUserMainInfo(users,context);

                    } else {

                    }

                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Log.i("Hello", "" + t);
                }
            });
            System.out.println("fbId " + refreshedToken);

        }
    }
}
