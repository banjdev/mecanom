package com.example.root.mecanomandroidhackaton.activity;

import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.root.mecanomandroidhackaton.ControlModel.changeMechanicLocation;
import com.example.root.mecanomandroidhackaton.ControlModel.getAllMaker;
import com.example.root.mecanomandroidhackaton.ControlModel.sendMechanicLocation;
import com.example.root.mecanomandroidhackaton.R;
import com.example.root.mecanomandroidhackaton.fragment.HistoryFragment;
import com.example.root.mecanomandroidhackaton.fragment.InfoFragment;
import com.example.root.mecanomandroidhackaton.fragment.MapHomeFragment;
import com.example.root.mecanomandroidhackaton.fragment.NotifFragment;
import com.example.root.mecanomandroidhackaton.fragment.VehicleFragment;
import com.example.root.mecanomandroidhackaton.model.Locations;
import com.example.root.mecanomandroidhackaton.model.Mechanic;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.GPSTracker;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.example.root.mecanomandroidhackaton.util.Utils.getDouble;
import static com.example.root.mecanomandroidhackaton.util.Utils.putDouble;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_INFO;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_LOCATION;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.saveLoggedout;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private Users users = null;
    private SharedPreferences mPrefs, mPrefsL, mPrefsI;
    private double longitude = 0.0;
    private double latittude = 0.0;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private GPSTracker gps;
    int PLACE_PICKER_REQUEST = 111;
    private String mechanicList_json;
    private List<Mechanic> mechanicList = new ArrayList<Mechanic>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mPrefs = getSharedPreferences(PREFS_USER_Main, MODE_PRIVATE);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerview = navigationView.getHeaderView(0);


        Bundle extras = getIntent().getExtras();
        String intentFragment = "null";
        String intentFragmentM = "null";
        if (extras != null) {
            intentFragment = extras.getString("history", "null");
            intentFragmentM = extras.getString("map", "null");

            System.out.println(intentFragment + "his");
            System.out.println(intentFragmentM + "mp");

        }

        if (intentFragment.equals("history")) {
            displaySelectedScreen(R.id.nav_history);

        }
        if (intentFragmentM.equals("map")) {
            displaySelectedScreen(R.id.nav_map);

        }

        if (users == null) {
            Gson gson = new Gson();
            String json = mPrefs.getString("user_main_info", "");
            users = gson.fromJson(json, Users.class);


        }
        if (users != null)  {

            TextView txt1 = (TextView) headerview.findViewById(R.id.textView1);
            txt1.setText(users.getEmail().substring(0, users.getEmail().indexOf('@')));

            TextView txt2 = (TextView) headerview.findViewById(R.id.textView2);
            txt2.setText(users.getEmail());

            if (users.getIsMechanic() == 0) {


                Gson gson = new Gson();
                mechanicList_json = getIntent().getStringExtra("userMechanic");
                mechanicList = gson.fromJson(mechanicList_json, new TypeToken<List<Users>>() {
                }.getType());



                mPrefsI = getSharedPreferences(PREFS_INFO, MODE_PRIVATE);
                SharedPreferences.Editor prefsEditor2 = mPrefsI.edit();
                prefsEditor2.commit();


                mPrefsL = getSharedPreferences(PREFS_LOCATION, MODE_PRIVATE);
                gps = new GPSTracker(MainActivity.this);
                longitude = getDouble(mPrefsL, "longitude", 0.0);
                latittude = getDouble(mPrefsL, "latittude", 0.0);
            }
            else
            {
                Menu navigationViewMenu = navigationView.getMenu();
                MenuItem menuItem = navigationViewMenu.findItem(R.id.nav_vehicule);
                MenuItem menuItem1 = navigationViewMenu.findItem(R.id.nav_main);
                MenuItem menuItem2 = navigationViewMenu.findItem(R.id.nav_map);
                MenuItem menuItem3 = navigationViewMenu.findItem(R.id.nav_location);
                menuItem.setVisible(false);
                menuItem1.setVisible(false);
                menuItem2.setVisible(false);
                menuItem3.setVisible(true);




                if (users.getLocation_id() == 0) {

                    if (longitude == 0.0 && latittude == 0.0) {
                        gps = new GPSTracker(MainActivity.this);
                        if (gps.canGetLocation()) {
                            ReqPermission();

                        } else {

                            gps.showSettingsAlert().setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    final Snackbar snackbarP;

                                    snackbarP = Snackbar.make(findViewById(android.R.id.content), getResources().getString(R.string.msg_permission), Snackbar.LENGTH_INDEFINITE);
                                    snackbarP.setAction("ok", new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            snackbarP.dismiss();
                                            ReqPermission();
                                        }
                                    }).show();

                                    startActivity(intent);
                                }
                            }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                                    final Snackbar snackbarP;

                                    snackbarP = Snackbar.make(findViewById(android.R.id.content), getResources().getString(R.string.msg_permission), Snackbar.LENGTH_INDEFINITE);
                                    snackbarP.setAction("ok", new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            snackbarP.dismiss();
                                            ReqPermission();
                                        }
                                    }).show();

                                    startActivity(intent);
                                }
                            });


                        }
                    }

                }

            initmsg(Snackbar.LENGTH_INDEFINITE, getResources().getText(R.string.msg_home_mecha).toString());

            }


        }
    }



    private void initmsg(int duration, String message) {
        final Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), message
                , duration);
        snackbar.setDuration((int) TimeUnit.MINUTES.toMillis(1));

        snackbar.setActionTextColor(getResources().getColor(R.color.toolbar_principal));

        View snackbarView = snackbar.getView();

        int snackbarTextId = android.support.design.R.id.snackbar_text;
        TextView textView = (TextView) snackbarView.findViewById(snackbarTextId);
        textView.setTextColor(getResources().getColor(android.R.color.black));
        textView.setLines(3);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                snackbar.dismiss();
            }
        });
        snackbarView.setBackgroundColor(getResources().getColor(android.R.color.white));

        snackbar.show();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                Place place = PlacePicker.getPlace(data, this);
                String toastMsg = String.format("Place: %s", place.getName());
                Toast.makeText(this, toastMsg, Toast.LENGTH_LONG).show();

                if (users.getIsMechanic() == 0) {

                    if (longitude == 0.0 && latittude == 0.0) {
                        if (place.isDataValid()) {
//                        Utils.clearSharedPreferences(this);
                            mPrefsL = getSharedPreferences(PREFS_LOCATION, MODE_PRIVATE);

                            SharedPreferences.Editor prefsEditor = mPrefsL.edit();

                            putDouble(prefsEditor, "longitude", place.getLatLng().longitude);
                            putDouble(prefsEditor, "latittude", place.getLatLng().latitude);
                            prefsEditor.commit();

                            longitude = getDouble(mPrefsL, "longitude", 0.0);
                            latittude = getDouble(mPrefsL, "latittude", 0.0);


//                        finish();
//                        startActivity(getIntent());
                            if (users.getIsMechanic() == 0)
                                startActivity(new Intent(this, MenuActivity.class));
                        }
                    }
                }

                if (users.getIsMechanic() == 1) {
                    if (place.isDataValid()) {
                        mPrefsL = getSharedPreferences(PREFS_LOCATION, MODE_PRIVATE);

                        SharedPreferences.Editor prefsEditor = mPrefsL.edit();

                        putDouble(prefsEditor, "longitude", place.getLatLng().longitude);
                        putDouble(prefsEditor, "latittude", place.getLatLng().latitude);
                        prefsEditor.commit();

                        longitude = getDouble(mPrefsL, "longitude", 0.0);
                        latittude = getDouble(mPrefsL, "latittude", 0.0);


                        if (users.getLocation_id() == 0) {
                            Locations locations = new Locations(latittude, longitude);

                            new sendMechanicLocation(users, locations, MainActivity.this).sendIt();
                        } else {
                            Locations locations = new Locations(place.getLatLng().latitude, place.getLatLng().longitude);

                            new changeMechanicLocation(users, locations, MainActivity.this).sendIt();
                            Log.d("Location", locations.toString());

                        }

                    }
                }
            }
        }
    }


    private void ReqPermission() {
        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

                new AlertDialog.Builder(this)
                        .setTitle("location")
                        .setMessage("we need your location to show you your location on the map")
                        .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();

            } else {

                // No explanation needed, we can request the permission.
                System.out.println("call permission");
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        } else {
            try {
                SearchingForLocation();

            } catch (Exception e) {

                final PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                alertDialog.setMessage("nous n'arrivons pas a trouver la posision,choisissez votre position sur la carte svp");


                alertDialog.setPositiveButton("ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                                try {
                                    startActivityForResult(builder.build(MainActivity.this), PLACE_PICKER_REQUEST);
                                } catch (GooglePlayServicesRepairableException e1) {
                                    e1.printStackTrace();
                                } catch (GooglePlayServicesNotAvailableException e1) {
                                    e1.printStackTrace();
                                }

                            }
                        });

                alertDialog.show();

            }
        }
    }

    private void SearchingForLocation() {

        if (gps.canGetLocation()) {

            Utils.ToastMsg(this, "Localisation en cours");

            gps = new GPSTracker(MainActivity.this);




            if (gps.getLocation() != null) {
                longitude = gps.getLongitude();
                latittude = gps.getLatitude();
                if (longitude != 0.0 && latittude != 0.0) {

                    if (users.getIsMechanic() == 1) {

                        Locations locations = new Locations(latittude, longitude);

//                        new sendMechanicLocation(users, locations, MainActivity.this).sendIt();


                    }

                     SharedPreferences.Editor prefsEditor = mPrefsL.edit();

                    putDouble(prefsEditor, "longitude", longitude);
                    putDouble(prefsEditor, "latittude", latittude);
                    prefsEditor.commit();
                    finish();
                    startActivity(getIntent());
                } else {
                    System.out.println("open in search location get location not null");

                    final PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                    final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                     alertDialog.setMessage("nous n'arrivons pas à trouver votre position, choisissez votre position manuellement svp");


                    alertDialog.setPositiveButton("ok",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {

                                    dialog.dismiss();

                                    try {
                                        startActivityForResult(builder.build(MainActivity.this), PLACE_PICKER_REQUEST);
                                    } catch (GooglePlayServicesRepairableException e1) {
                                        e1.printStackTrace();
                                    } catch (GooglePlayServicesNotAvailableException e1) {
                                        e1.printStackTrace();
                                    }

                                }
                            });


                    alertDialog.show();
                }

            } else {

                System.out.println("open in search location get location null");

                final PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
//                    alertDialog.setTitle(R.string.msgChangeUsername);
                alertDialog.setMessage("nous n'arrivons pas a trouver la posision,choisissez votre position sur la carte svp");


                alertDialog.setPositiveButton("ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                try {
                                    startActivityForResult(builder.build(MainActivity.this), PLACE_PICKER_REQUEST);
                                } catch (GooglePlayServicesRepairableException e1) {
                                    e1.printStackTrace();
                                } catch (GooglePlayServicesNotAvailableException e1) {
                                    e1.printStackTrace();
                                }

                            }
                        });


                alertDialog.show();
            }
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        displaySelectedScreen(item.getItemId());


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void displaySelectedScreen(int itemId) {
        Fragment fragment = null;

        int id = itemId;

        if (id == R.id.nav_info) {
            fragment = new InfoFragment();
        }
        if (id == R.id.nav_main) {
            if (users != null) {

                System.out.println("user not null");

                new getAllMaker(users,MainActivity.this).getAll();
            }

        } else if (id == R.id.nav_vehicule) {
            fragment = new VehicleFragment();


        } else if (id == R.id.nav_map) {
            if (users != null) {

                System.out.println("user not null");

                new getAllMaker(users,MainActivity.this).getAll();
            }

            fragment = new MapHomeFragment();


        } else if (id == R.id.nav_notification) {
            fragment = new NotifFragment();
        } else if (id == R.id.nav_setting) {

            if (users != null) {


                AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
//                    alertDialog.setTitle(R.string.msgChangeUsername);
                alertDialog.setMessage("Souhaiteriez-vous vraiment déconnecter?");


                alertDialog.setPositiveButton("OUI",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                saveLoggedout(MainActivity.this);
                                MainActivity.this.getSharedPreferences(PREFS_USER_Main, MODE_PRIVATE).edit().clear().commit();
                                Utils.ToastMsg(MainActivity.this, "Déconnecté avec succes");
                                startActivity(new Intent(MainActivity.this, SplashActivity.class));
                            }
                        });

                alertDialog.setNegativeButton("NON",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });

                alertDialog.show();
            } else {
                Utils.ToastMsg(MainActivity.this, "Vous n'êtes pas connecté");
                startActivity(new Intent(MainActivity.this, LoginActivity.class));

            }

        } else if (id == R.id.nav_share) {
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "Mecanom");
                String sAux = "\nLaissez moi vous recommandez cette application\n\n";
                sAux = sAux + "https://play.google.com/store/apps/ \n\n";
                i.putExtra(Intent.EXTRA_TEXT, sAux);
                startActivity(Intent.createChooser(i, " "));
            } catch (Exception e) {
            }
        } else if (id == R.id.nav_history) {
            fragment = new HistoryFragment();

        }

        else if (id == R.id.nav_location) {
            final PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();

            try {
                startActivityForResult(builder.build(MainActivity.this), PLACE_PICKER_REQUEST);
            } catch (GooglePlayServicesRepairableException e1) {
                e1.printStackTrace();
            } catch (GooglePlayServicesNotAvailableException e1) {
                e1.printStackTrace();
            }





        }

        //replacing the fragment
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment);
            ft.commit();
        }
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
//            super.onBackPressed();

            AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
//                    alertDialog.setTitle(R.string.msgChangeUsername);
            alertDialog.setMessage("Souhaiteriez-vous vraiment quitter?");


            alertDialog.setPositiveButton("OUI",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            finishAffinity();
                        }
                    });

            alertDialog.setNegativeButton("NON",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

            alertDialog.show();
        }
    }

}
