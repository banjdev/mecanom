package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.util.Log;

import com.example.root.mecanomandroidhackaton.activity.MainActivity;
import com.example.root.mecanomandroidhackaton.activity.MenuActivity;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.example.root.mecanomandroidhackaton.util.UtilsMecanom;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import retrofit2.Call;
import retrofit2.Callback;

import static android.content.Context.MODE_PRIVATE;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_LOCATION;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.saveLoggedIN;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.saveUserMainInfo;




public class CustomRegistration extends AsyncTask {
    Users users;
    Intent i;
    Context context;
    String type;
    private SharedPreferences mPrefsL;

    public CustomRegistration(Users users, Context context) {
        this.users = users;
        this.context = context;
    }


    public void InsertInfo() {
        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Un instant ...");
        progressDialog.setMessage("Inscription en cours");
        progressDialog.show();
        ApiService service = getApiService();

        mPrefsL = context.getSharedPreferences(PREFS_LOCATION,MODE_PRIVATE);
        final String fbtoken = mPrefsL.getString("fbtoken", "");
        if(fbtoken == null){
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                            if (!task.isSuccessful()) {
                                return;
                            }

                            // Get new Instance ID token
                            String fbtoken = task.getResult().getToken();
                            UtilsMecanom.saveFbToken(fbtoken, context);

                        }
                    });
        }
        System.out.println("getrefresh"+fbtoken);
        Call<Users> call = service.insertDataE(users.getEmail(),users.getPassword(),fbtoken);
//        Call<Users> call = service.insertDataE(users);
        call.enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, retrofit2.Response<Users> response) {
                Log.i("Halla",""+response);

                if (response.code() == 200 ) {
                    users = response.body();
                    saveUserMainInfo(users,context);
                    saveLoggedIN(context);
                     new sendFbTokenToServer(context).sendRegistrationToServer(fbtoken);


                    if(users.getIsMechanic() == 0) {
                         progressDialog.dismiss();
                        context.startActivity(new Intent(context,MenuActivity.class).putExtra("from_registration",true));

                     }
                    else{
                        progressDialog.dismiss();
                        context.startActivity(new Intent(context,MainActivity.class));

                    }
                }
                else if(response.code() == 409) {
                    progressDialog.dismiss();
                    Utils.ToastMsg(context,"email existant");
                }
                else {
                    progressDialog.dismiss();
                    Utils.ToastMsg(context,"erreur de connexion1,reesayez");
                    Log.d("erreur marco", response.message());
                }

            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                Log.i("Hello", ""+t);
                progressDialog.dismiss();
                Utils.ToastMsg(context,"erreur de connexion2,reesayez");
            }
        });

    }

    public void login(){
        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Un instant ...");
        progressDialog.setMessage("Connexion en cours");
        progressDialog.show();
        ApiService service = getApiService();
        mPrefsL = context.getSharedPreferences(PREFS_LOCATION,MODE_PRIVATE);
        final String fbtoken = mPrefsL.getString("fbtoken", "");

        if(fbtoken == null){
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                            if (!task.isSuccessful()) {

                                return;
                            }

                            // Get fbtoken Instance ID token
                            String token = task.getResult().getToken();
                            UtilsMecanom.saveFbToken(fbtoken, context);

                         }
                    });
        }
        System.out.println("getrefresh"+fbtoken);

        Call<Users> call = service.loginE(users.getEmail(),users.getPassword(),fbtoken);

        call.enqueue(new Callback<Users>() {
            @Override
            public void onResponse(Call<Users> call, retrofit2.Response<Users> response) {
                Log.i("Halla",""+response);
                if (response.code() == 200) {
                    users = response.body();
                    saveUserMainInfo(users,context);
                    saveLoggedIN(context);
                     new sendFbTokenToServer(context).sendRegistrationToServer(fbtoken);
                    progressDialog.dismiss();
                    if(users.getIsMechanic() == 0) {
//
                        context.startActivity(new Intent(context,MenuActivity.class));
                      }
                    else{
                        context.startActivity(new Intent(context, MainActivity.class));
                    }
                }
                else {
                    // Handle other response codes
                    progressDialog.dismiss();
                    if(response.code() != 500){
                        Utils.ToastMsg(context,"email ou mot de passe incorrect,reesayez");
                    }
                    else{
                        Utils.ToastMsg(context,"erreur de connexion1,reesayez");
                    }
                }

            }

            @Override
            public void onFailure(Call<Users> call, Throwable t) {
                Log.i("Hello", ""+t);
                progressDialog.dismiss();
                Utils.ToastMsg(context,"erreur de connexion2,reesayez");
            }
        });
    }


    @Override
    protected Object doInBackground(Object[] objects) {
        if (type.equals("signup"))
          InsertInfo();
        if (type.equals("login"))
            login();

        return null;
    }
}
