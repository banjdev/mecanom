package com.example.root.mecanomandroidhackaton.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Garage  implements Parcelable {

    @SerializedName("id")
    @Expose
    private int id;



    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("mechanic_id")
    @Expose
    private int mechanicId;
    @SerializedName("addresse")
    @Expose
    private String addresse;
    @SerializedName("creation_date")
    @Expose
    private String creationDate;

    public final static Parcelable.Creator<Mechanic> CREATOR = new Creator<Mechanic>() {


        @SuppressWarnings({
                "unchecked"
        })
        public Mechanic createFromParcel(Parcel in) {
            return new Mechanic(in);
        }

        public Mechanic[] newArray(int size) {
            return (new Mechanic[size]);
        }

    }
            ;

    protected Garage(Parcel in) {
        this.id = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.mechanicId = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.name = ((String) in.readValue((String.class.getClassLoader())));
        this.addresse = ((String) in.readValue((String.class.getClassLoader())));

    }

    /**
     * No args constructor for use in serialization
     *
     */
    public Garage() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMechanicId() {
        return mechanicId;
    }

    public void setMechanicId(int mechanicId) {
        this.mechanicId = mechanicId;
    }

    public String getAddresse() {
        return addresse;
    }

    public void setAddresse(String addresse) {
        this.addresse = addresse;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Mechanic{" +
                "id='" + id + '\'' +
                ", location='" + mechanicId + '\'' +

                ", user_id='" + name + '\'' +
                ", haveScanner='" + addresse + '\'' +
                '}';
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(mechanicId);
        dest.writeValue(name);
        dest.writeValue(addresse);

    }

    public int describeContents() {
        return 0;
    }


}
