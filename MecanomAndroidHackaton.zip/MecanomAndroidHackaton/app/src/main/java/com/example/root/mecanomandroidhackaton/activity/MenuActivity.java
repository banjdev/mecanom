package com.example.root.mecanomandroidhackaton.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.root.mecanomandroidhackaton.ControlModel.getAllMaker;
import com.example.root.mecanomandroidhackaton.fragment.VehicleFragment;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.google.gson.Gson;
import com.example.root.mecanomandroidhackaton.R;


import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;

public class MenuActivity extends AppCompatActivity {

     private Users users = null ;
    private SharedPreferences mPrefs ;
    private Button depannage,availablemechanic,remorquage ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        bindViews();
        setListeners();

        mPrefs = getSharedPreferences(PREFS_USER_Main,MODE_PRIVATE);

        Gson gson = new Gson();
        String json = mPrefs.getString("user_main_info", "");
        users = gson.fromJson(json, Users.class);

        if(users == null)
            System.out.println("user null in menu");




//        mGridMenuFragment.setOnClickMenuListener(new GridMenuFragment.OnClickMenuListener() {
//            @Override
//            public void onClickMenu(GridMenu gridMenu, int position) {
////                Toast.makeText(MenuActivity.this, "Title:" + gridMenu.getTitle() + ", Position:" + position,
////                        Toast.LENGTH_SHORT).show();
//                if(position == 0)
//                    new getAllMaker(users, 1,MenuActivity.this).getAll();
//            }
//        });
    }


    @Override
    public void onBackPressed() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(MenuActivity.this);
//                    alertDialog.setTitle(R.string.msgChangeUsername);
        alertDialog.setMessage("Souhaiterez-vous vraiment quitter?");



        alertDialog.setPositiveButton("OUI",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finishAffinity();
                    }
                });

        alertDialog.setNegativeButton("NON",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();
    }
private void setListeners() {

    availablemechanic.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // Perform custom sign in
            new getAllMaker(users, MenuActivity.this).getAll();
        }
    });

    depannage.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MenuActivity.this,FormRequestActivity.class);
            intent.putExtra("from_registration",true);
            startActivity(intent);
        }
    });

    remorquage.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(MenuActivity.this,"coming soon", Toast.LENGTH_SHORT).show();
        }
    });


}


    private void bindViews() {
        depannage = (Button) findViewById(R.id.depannage);
        availablemechanic = (Button) findViewById(R.id.availablemechanic);
        remorquage = (Button) findViewById(R.id.remorquage);
    }
}
