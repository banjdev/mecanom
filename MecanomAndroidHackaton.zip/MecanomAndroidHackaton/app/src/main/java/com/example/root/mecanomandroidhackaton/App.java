package com.example.root.mecanomandroidhackaton;

import android.app.Application;
import android.content.Context;

import com.google.firebase.FirebaseApp;



public class App extends Application {
    private static App mInstance;

    public static App getInstance(){
        return mInstance;
    }
    public static Context getAppContext(){
        return mInstance;
    }
    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        FirebaseApp.initializeApp(this);

    }
    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}
