package com.example.root.mecanomandroidhackaton.fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.root.mecanomandroidhackaton.ControlModel.getAllHisto;
import com.example.root.mecanomandroidhackaton.adapter.HistoryAdapter;
import com.example.root.mecanomandroidhackaton.model.Notifications;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.PREFS_USER_Main;
import com.example.root.mecanomandroidhackaton.R;

public class HistoryFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener  {

    private RecyclerView recyclerView;
    private HistoryAdapter adapter;

    private SharedPreferences mPrefs ;
    private Users users = null;
    private boolean haveNotif = false;
    private int notif_id;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    List<Notifications> notifications= new ArrayList<Notifications>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Historique");

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.activity_history, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

//        Utils.ToastCustom(this,R.layout.toast_history, Toast.LENGTH_LONG,R.dimen.toast_vertical_margin).show();

//        Snackbar.make(findViewById(android.R.id.content),"pas d'historique", Snackbar.LENGTH_LONG).show();
        mSwipeRefreshLayout = (SwipeRefreshLayout) getView().findViewById(R.id.activity_main_swipe_refresh_layout);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        recyclerView =  getView().findViewById(R.id.recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        mPrefs = getContext().getSharedPreferences(PREFS_USER_Main, MODE_PRIVATE);

        Gson gson = new Gson();
        String json = mPrefs.getString("user_main_info", "");
        users = gson.fromJson(json, Users.class);

        adapter = new HistoryAdapter(notifications,users.getIsMechanic(),getContext(),users);
        recyclerView.setAdapter(adapter);



        haveNotif = new getAllHisto(users,getContext(),adapter).getAll();
    }


    @Override
    public void onRefresh() {
            refreshContent();
            }

    private void refreshContent(){
        if(haveNotif == false){
            if (Utils.isIntenetAvailavle(getContext()))
                new getAllHisto(users,getContext(),adapter).getAll();
            else
                Utils.ToastMsg(getContext(),"verifiez votre connection,reessayez");
        }

        mSwipeRefreshLayout.setRefreshing(false);
    }

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        switch (id) {
//            case android.R.id.home:
//            {
//                onBackPressed();
//                return true;
//            }
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }

}
