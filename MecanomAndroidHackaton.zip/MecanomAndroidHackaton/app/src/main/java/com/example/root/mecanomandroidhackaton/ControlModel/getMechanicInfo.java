package com.example.root.mecanomandroidhackaton.ControlModel;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;

import com.example.root.mecanomandroidhackaton.activity.ProfilGaragistActivity;
import com.example.root.mecanomandroidhackaton.model.Mechanic;
import com.example.root.mecanomandroidhackaton.model.Users;
import com.example.root.mecanomandroidhackaton.util.Utils;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import com.example.root.mecanomandroidhackaton.R;


import static com.example.root.mecanomandroidhackaton.util.UtilsMecanom.getApiService;



public class getMechanicInfo {

    private Mechanic userMechanic = null;
    private String token;
    private Context context;
    private int mechanic_id;
    private Users users =null;

    public getMechanicInfo(Context context, Users users, int mechanic_id   ) {
        this.users = users;
        this.context = context;
        this.mechanic_id = mechanic_id;
     }

    public void getIt( ) {


        ApiService service = getApiService();
        token = "Bearer " + users.getToken();

         Call<Mechanic> call = service.getMechanicInfo(token,mechanic_id );



        call.enqueue(new Callback<Mechanic>() {
            @Override
            public void onResponse(Call<Mechanic> call, Response<Mechanic> response) {
                Log.i("Halla", "" + response);
                if (response.code() == 200) {
                    userMechanic = response.body();
                    Gson gson = new Gson();
                    String json = gson.toJson(userMechanic);

                        context.startActivity(new Intent(context, ProfilGaragistActivity.class)
                            .putExtra("userMechanic", json));
                 }
                 else
                    Utils.ToastMsg(context,"erreur de connexion1,reesayez");

                ((Activity)context).findViewById(R.id.loadingPanel).setVisibility(View.GONE);
            }

            @Override
            public void onFailure(Call<Mechanic> call, Throwable t) {
                Log.i("Hello", "" + t);
                Utils.ToastMsg(context,"erreur de connexion2,reesayez");
                ((Activity)context).findViewById(R.id.loadingPanel).setVisibility(View.GONE);
             }
        });

    }


}
