package com.example.root.mecanomandroidhackaton.model;



import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Notifications implements Parcelable
{

    @SerializedName("id")
    @Expose
    private int id;



    @SerializedName("reqest_emergency_id")
    @Expose
    private int reqest_emergency_id;
    @SerializedName("principal_id")
    @Expose
    private int principal_id;
    @SerializedName("mechanic_id")
    @Expose
    private int mechanic_id;
    @SerializedName("driver_id")
    @Expose
    private int driver_id;
    @SerializedName("mechanic_name")
    @Expose
    private String mechanic_name;



    @SerializedName("garage_address")
    @Expose
    private String garage_address;

    @SerializedName("garage_name")
    @Expose
    private String garage_name;



    @SerializedName("driver_name")
    @Expose
    private String driver_name;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("body")
    @Expose
    private String body;
    @SerializedName("read")
    @Expose
    private int read;
    @SerializedName("status")
    @Expose
    private int status;
    @SerializedName("date")
    @Expose
    private String date;
    @SerializedName("delay")
    @Expose
    private String delay;
    @SerializedName("detailVehicule")
    @Expose
    private DetailVehicule detailVehicule;
    @SerializedName("locations")
    @Expose
    private Locations locations;
    public final static Parcelable.Creator<Notifications> CREATOR = new Creator<Notifications>() {


        @SuppressWarnings({
                "unchecked"
        })
        public Notifications createFromParcel(Parcel in) {
            return new Notifications(in);
        }

        public Notifications[] newArray(int size) {
            return (new Notifications[size]);
        }

    }
            ;

    protected Notifications(Parcel in) {
        this.id = ((int) in.readValue((int.class.getClassLoader())));
        this.principal_id = ((int) in.readValue((int.class.getClassLoader())));
        this.driver_name = ((String) in.readValue((String.class.getClassLoader())));
        this.mechanic_name = ((String) in.readValue((String.class.getClassLoader())));
        this.garage_name = ((String) in.readValue((String.class.getClassLoader())));
        this.garage_address = ((String) in.readValue((String.class.getClassLoader())));
        this.title = ((String) in.readValue((String.class.getClassLoader())));
        this.body = ((String) in.readValue((String.class.getClassLoader())));
        this.read = ((int) in.readValue((int.class.getClassLoader())));
        this.date = ((String) in.readValue((String.class.getClassLoader())));
        this.status = ((int) in.readValue((String.class.getClassLoader())));
        this.delay = ((String) in.readValue((String.class.getClassLoader())));
        this.mechanic_id = ((int) in.readValue((int.class.getClassLoader())));
        this.driver_id = ((int) in.readValue((int.class.getClassLoader())));
        this.reqest_emergency_id = ((int) in.readValue((int.class.getClassLoader())));
        this.detailVehicule = ((DetailVehicule) in.readValue((DetailVehicule.class.getClassLoader())));
        this.locations = ((Locations) in.readValue((Locations.class.getClassLoader())));

    }

    public Notifications() {
    }

    public Notifications(String title, String body) {
        this.title = title;
        this.body = body;
    }

    public int getReqest_emergency_id() {
        return reqest_emergency_id;
    }

    public void setReqest_emergency_id(int reqest_emergency_id) {
        this.reqest_emergency_id = reqest_emergency_id;
    }

    public String getMechanic_name() {
        return mechanic_name;
    }

    public void setMechanic_name(String mechanic_name) {
        this.mechanic_name = mechanic_name;
    }

    public String getDriver_name() {
        return driver_name;
    }

    public void setDriver_name(String driver_name) {
        this.driver_name = driver_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public int getRead() {
        return read;
    }

    public void setRead(int read) {
        this.read = read;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }


    public int getPrincipal_id() {
        return principal_id;
    }

    public void setPrincipal_id(int principal_id) {
        this.principal_id = principal_id;
    }

    public DetailVehicule getDetailVehicule() {
        return detailVehicule;
    }

    public void setDetailVehicule(DetailVehicule detailVehicule) {
        this.detailVehicule = detailVehicule;
    }

    public Locations getLocations() {
        return locations;
    }

    public void setLocations(Locations locations) {
        this.locations = locations;
    }

    public String getDelay() {
        return delay;
    }

    public void setDelay(String delay) {
        this.delay = delay;
    }


    public int getMechanic_id() {
        return mechanic_id;
    }

    public void setMechanic_id(int mechanic_id) {
        this.mechanic_id = mechanic_id;
    }

    public int getDriver_id() {
        return driver_id;
    }

    public void setDriver_id(int driver_id) {
        this.driver_id = driver_id;
    }

    public String getGarage_name() {
        return garage_name;
    }

    public void setGarage_name(String garage_name) {
        this.garage_name = garage_name;
    }

    public String getGarage_address() {
        return garage_address;
    }

    public void setGarage_address(String garage_address) {
        this.garage_address = garage_address;
    }



    @Override
    public String toString() {
        return "Notifications{" +
                "id='" + id + '\'' +
                "principal_id='" + principal_id + '\'' +
                "mechanic_id='" + mechanic_id + '\'' +
                "driver_id='" + driver_id + '\'' +
                "reqest_emergency_id='" + reqest_emergency_id + '\'' +
                ", driver_name='" + driver_name + '\'' +
                ", mechanic_name='" + mechanic_name + '\'' +
                ", garage_name='" + garage_name + '\'' +
                ", garage_name='" + garage_address + '\'' +
                ", title='" + title + '\'' +
                ", read='" + read + '\'' +
                ", body='" + body + '\'' +
                ", date='" + date + '\'' +
                ", delay='" + delay + '\'' +
                ", status='" + status + '\'' +
                ", detailVehicule='" + detailVehicule + '\'' +
                ", locations='" + locations + '\'' +
                '}';
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(id);
        dest.writeValue(principal_id);
        dest.writeValue(mechanic_id);
        dest.writeValue(driver_id);
        dest.writeValue(reqest_emergency_id);
        dest.writeValue(driver_name);
        dest.writeValue(mechanic_name);
        dest.writeValue(garage_name);
        dest.writeValue(garage_address);
        dest.writeValue(title);
        dest.writeValue(body);
        dest.writeValue(read);
        dest.writeValue(delay);
        dest.writeValue(date);
        dest.writeValue(status);
        dest.writeValue(detailVehicule);
        dest.writeValue(locations);
    }

    public int describeContents() {
        return 0;
    }

}